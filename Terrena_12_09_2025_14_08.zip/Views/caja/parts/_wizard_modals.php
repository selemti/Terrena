<?php /* Fragmento del modal wizard (no cambiar clases propias del proyecto) */ ?>
<div class="modal fade" id="czModalPrecorte" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">Precorte / Corte</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <div class="progress mb-3" style="height:6px;">
          <div id="czStepBar" class="progress-bar" role="progressbar" style="width:33%"></div>
        </div>

        <!-- Paso 1 -->
        <section id="czStep1">
          <div class="row g-3">
            <div class="col-md-6">
              <table class="table table-sm" id="czTablaDenoms">
                <thead><tr><th>Denom</th><th>Cantidad</th><th class="text-end">Subtotal</th></tr></thead>
                <tbody></tbody>
              </table>
              <div class="mt-2">Total efectivo declarado: <strong id="czPrecorteTotal">$0.00</strong></div>
              <div class="mt-1 small text-muted">Fondo: <span id="czChipFondo">$0.00</span></div>
              <div class="mt-1 small text-muted">Efectivo esperado: <span id="czEfectivoEsperado">$0.00</span></div>
            </div>
            <div class="col-md-6">
              <label class="form-label">Tarjeta Crédito</label>
              <input id="czDeclCardCredito" type="number" min="0" step="0.01" class="form-control form-control-sm" value="0">
              <label class="form-label mt-2">Tarjeta Débito</label>
              <input id="czDeclCardDebito" type="number" min="0" step="0.01" class="form-control form-control-sm" value="0">
              <label class="form-label mt-2">Transferencias</label>
              <input id="czDeclTransfer" type="number" min="0" step="0.01" class="form-control form-control-sm" value="0">
              <label class="form-label mt-2">Notas</label>
              <textarea id="czNotes" class="form-control form-control-sm" rows="3"></textarea>
              <input type="hidden" id="cz_precorte_id" value="">
            </div>
          </div>
        </section>

        <!-- Paso 2 -->
        <section id="czStep2" class="d-none">
          <div id="czBannerFaltaCorte" class="alert alert-info d-none">Sin datos de POS. Verifica sincronización.</div>
          <div class="d-flex justify-content-between align-items-center mb-2">
            <div class="fw-semibold">Conciliación</div>
            <div>
              <button id="czBtnSincronizarPOS" class="btn btn-sm btn-outline-secondary">Sincronizar POS</button>
            </div>
          </div>
          <div id="czConciliacionGrid"></div>
          <label id="czConciliacionNotasLabel" class="form-label mt-2">Notas (opcional)</label>
          <textarea id="czConciliacionNotas" class="form-control form-control-sm" rows="2"></textarea>
        </section>

        <!-- Paso 3 -->
        <section id="czStep3" class="d-none">
          <div id="czCorteResumen" class="mb-3 small text-muted">Resumen listo tras conciliación.</div>
          <div class="row g-2">
            <div class="col-md-4"><input id="czDepFolio" class="form-control form-control-sm" placeholder="Folio depósito (opcional)"></div>
            <div class="col-md-4"><input id="czDepCuenta" class="form-control form-control-sm" placeholder="Cuenta destino (opcional)"></div>
            <div class="col-md-4"><input id="czDepEvidencia" class="form-control form-control-sm" placeholder="URL evidencia (opcional)"></div>
          </div>
          <label class="form-label mt-2">Notas de cierre</label>
          <textarea id="czNotasCierre" class="form-control form-control-sm" rows="2"></textarea>
        </section>
      </div>

      <div class="modal-footer">
        <button id="czBtnGuardarPrecorte"    class="btn btn-success">Guardar precorte</button>
        <button id="czBtnContinuarConciliacion" class="btn btn-primary d-none">Continuar</button>
        <button id="czBtnIrPostcorte"        class="btn btn-warning d-none">Ir a Postcorte</button>
        <button id="czBtnCerrarSesion"       class="btn btn-danger d-none">Cerrar sesión</button>
      </div>
    </div>
  </div>
</div>
