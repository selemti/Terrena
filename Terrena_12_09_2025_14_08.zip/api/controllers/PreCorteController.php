<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class PreCorteController {

  /** Resuelve PDO sin tocar tu core (intenta /api/config.php, luego /config.php; si no, usa pdo() existente) */
  private static function p(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    $candidates = [
      __DIR__ . '/../config.php',   // /api/config.php
      __DIR__ . '/../../config.php' // /config.php
    ];
    foreach ($candidates as $c) {
      if (is_file($c)) {
        $r = require $c;
        if ($r instanceof PDO) { $pdo = $r; return $pdo; }
      }
    }
    if (function_exists('pdo')) {
      $pdo = pdo();
      if ($pdo instanceof PDO) return $pdo;
    }
    throw new RuntimeException('No fue posible inicializar PDO en PreCorteController.');
  }

  /* ===== Preflight (bloqueos por tickets abiertos) ===== */
  public static function preflight(Request $request, Response $response, array $args = []) : Response {
    $db  = self::p();
    $sid = isset($args['sesion_id']) ? (int)$args['sesion_id'] : (int) qp($request, 'sesion_id', 0);
    if (!$sid) return J($response, ['ok'=>false,'error'=>'missing_sesion_id'], 400);

    // terminal de la sesión
    $st = $db->prepare("SELECT terminal_id FROM selemti.sesion_cajon WHERE id=:id");
    $st->execute([':id'=>$sid]);
    $row = $st->fetch();
    if (!$row) return J($response, ['ok'=>false,'error'=>'sesion_not_found'], 404);
    $tid = (int)$row['terminal_id'];

    // tickets abiertos en esa terminal (no pagados, no void)
    $t = $db->prepare("
      SELECT COUNT(*) AS c
      FROM public.ticket
      WHERE terminal_id=:tid
        AND COALESCE(paid,false)=false
        AND COALESCE(voided,false)=false
    ");
    $t->execute([':tid'=>$tid]);
    $open = (int)($t->fetch()['c'] ?? 0);

    $blocked = $open > 0;
    return J($response, [
      'ok'=>!$blocked,
      'tickets_abiertos'=>$open,
      'bloqueo'=>$blocked
    ], 200);
  }

  /* ===== Crear/Actualizar encabezado (upsert) ===== */
  public static function createOrUpdate(Request $request, Response $response, array $args = []) : Response {
    $db  = self::p();
    $sid = (int) qp($request, 'sesion_id', 0);

    // si vino id de precorte, resolver sesión
    $precorte_id_in = (int) qp($request, 'id', 0);
    if (!$sid && $precorte_id_in) {
      $tmp = $db->prepare("SELECT sesion_id FROM selemti.precorte WHERE id=:id");
      $tmp->execute([':id'=>$precorte_id_in]);
      $sid = (int)($tmp->fetch()['sesion_id'] ?? 0);
    }

    if (!$sid) {
      $tid   = (int) qp($request, 'terminal_id', 0);
      $uid   = (int) qp($request, 'user_id', 0);
      $bdate = (string) (qp($request, 'bdate') ?? qp($request, 'date') ?? '');
      if (!$tid || !$uid || !$bdate) {
        return J($response, ['ok'=>false,'error'=>'missing_params (sesion_id) OR (terminal_id,user_id,bdate)'], 400);
      }
      $q = $db->prepare("
        SELECT id
        FROM selemti.sesion_cajon
        WHERE terminal_id = :tid
          AND cajero_usuario_id = :uid
          AND (apertura_ts::date = :d OR (cierre_ts IS NOT NULL AND cierre_ts::date = :d))
        ORDER BY apertura_ts DESC
        LIMIT 1
      ");
      $q->execute([':tid'=>$tid, ':uid'=>$uid, ':d'=>$bdate]);
      $sid = (int)($q->fetch()['id'] ?? 0);
      if (!$sid) {
        $q2 = $db->prepare("
          SELECT id FROM selemti.sesion_cajon
          WHERE terminal_id=:tid AND cajero_usuario_id=:uid AND estatus='ACTIVA'
          ORDER BY apertura_ts DESC LIMIT 1
        ");
        $q2->execute([':tid'=>$tid, ':uid'=>$uid]);
        $sid = (int)($q2->fetch()['id'] ?? 0);
      }
      if (!$sid) return J($response, ['ok'=>false,'error'=>'sesion_not_found','detail'=>compact('tid','uid','bdate')], 404);
    }

    // Bloqueo por tickets abiertos
    $pre = self::preflight($request, new \Slim\Psr7\Response(), ['sesion_id'=>$sid]);
    $preData = json_decode((string)$pre->getBody(), true);
    if (!$preData['ok']) return J($response, $preData, 409);

    // Upsert encabezado
    $st = $db->prepare("SELECT id FROM selemti.precorte WHERE sesion_id=:sid ORDER BY id DESC LIMIT 1");
    $st->execute([':sid'=>$sid]);
    $precorte_id = (int)($st->fetch()['id'] ?? 0);

    if (!$precorte_id) {
      $ins = $db->prepare("INSERT INTO selemti.precorte (sesion_id, estatus) VALUES (:sid,'PENDIENTE') RETURNING id");
      $ins->execute([':sid'=>$sid]);
      $precorte_id = (int)$ins->fetch()['id'];
    }

    return J($response, ['ok'=>true,'precorte_id'=>$precorte_id,'sesion_id'=>$sid]);
  }

  /* ===== Resumen (nuevo diseño; acepta id o sesion_id) ===== */
  public static function resumen(Request $request, Response $response, array $args) {
    $db        = self::p();
    $id        = isset($args['id']) ? (int)$args['id'] : (int) qp($request, 'id', 0);
    $sesion_id = isset($args['sesion_id']) ? (int)$args['sesion_id'] : (int) qp($request, 'sesion_id', 0);

    if (!$id && $sesion_id) {
      $s = $db->prepare("SELECT id FROM selemti.precorte WHERE sesion_id=:sid ORDER BY id DESC LIMIT 1");
      $s->execute([':sid'=>$sesion_id]);
      $id = (int)($s->fetch()['id'] ?? 0);
    }
    if (!$id) return J($response, ['ok'=>false,'error'=>'precorte_not_found'], 404);

    $p = $db->prepare("SELECT sesion_id FROM selemti.precorte WHERE id=:id");
    $p->execute([':id'=>$id]);
    $rowP = $p->fetch();
    if(!$rowP) return J($response, ['ok'=>false,'error'=>'precorte_not_found'],404);
    $sid = (int)$rowP['sesion_id'];

    // declarado efectivo
    $tEF = $db->prepare("SELECT COALESCE(SUM(subtotal),0)::numeric s FROM selemti.precorte_efectivo WHERE precorte_id=:id");
    $tEF->execute([':id'=>$id]);
    $decl_ef = (float)($tEF->fetch()['s'] ?? 0);

    // otros (si existe la tabla)
    $decl_ot = ['CREDITO'=>0,'DEBITO'=>0,'TRANSFER'=>0,'CUSTOM'=>0,'GIFT_CERT'=>0];
    $hasOtros = !empty($db->query("SELECT to_regclass('selemti.precorte_otros') AS t")->fetch()['t']);
    if($hasOtros){
      $qot = $db->prepare("SELECT UPPER(tipo) AS tipo, COALESCE(SUM(monto),0)::numeric AS monto
                           FROM selemti.precorte_otros WHERE precorte_id=:id GROUP BY UPPER(tipo)");
      $qot->execute([':id'=>$id]);
      foreach($qot as $r){
        $k = $r['tipo'];
        if (isset($decl_ot[$k])) $decl_ot[$k] = (float)$r['monto'];
      }
    }

    // sistema via vista (claves tolerantes)
    $vw = $db->prepare("SELECT * FROM selemti.vw_conciliacion_sesion WHERE sesion_id=:sid");
    $vw->execute([':sid'=>$sid]);
    $sys = [
      'cash'=>0,'credit'=>0,'debit'=>0,'transfer'=>0,'custom'=>0,'gift'=>0,
      'retiros'=>0,'refunds_cash'=>0,'sistema_efectivo_esperado'=>0,'sistema_tarjetas'=>0
    ];
    if($r = $vw->fetch()){
      $cash     = (float)($r['sys_cash']     ?? $r['cash']     ?? 0);
      $credit   = (float)($r['sys_credito']  ?? $r['sys_credit']   ?? $r['credit']   ?? 0);
      $debit    = (float)($r['sys_debito']   ?? $r['sys_debit']    ?? $r['debit']    ?? 0);
      $transfer = (float)($r['sys_transfer'] ?? $r['transfer'] ?? 0);
      $custom   = (float)($r['sys_custom']   ?? $r['custom']   ?? 0);
      $gift     = (float)($r['sys_gift']     ?? 0);

      $sys['cash']=$cash; $sys['credit']=$credit; $sys['debit']=$debit; $sys['transfer']=$transfer; $sys['custom']=$custom; $sys['gift']=$gift;
      $sys['retiros']=(float)($r['retiros'] ?? 0);
      $sys['refunds_cash']=(float)($r['refunds_cash'] ?? $r['reembolsos_efectivo'] ?? 0);
      $sys['sistema_efectivo_esperado']=(float)($r['sistema_efectivo_esperado'] ?? 0);
      $sys['sistema_tarjetas']=$credit+$debit+$transfer+$custom+$gift;
    }

    $dif = [
      'efectivo' => round($decl_ef - $sys['sistema_efectivo_esperado'], 2),
      'tarjetas' => round(array_sum($decl_ot) - $sys['sistema_tarjetas'], 2)
    ];

    return J($response, [
      'ok'=>true,
      'sesion'=>['id'=>$sid],
      'sistema'=>$sys,
      'declarado'=>['efectivo'=>$decl_ef,'otros'=>$decl_ot],
      'dif'=>$dif,
      'umbral'=>DIFF_THRESHOLD
    ]);
  }

  /* ===== Legacy: payload para wizard (espera j.data.*) ===== */
  public static function resumenLegacy(Request $request, Response $response, array $args = []) {
    $db = self::p();
    $precorte_id = isset($args['id']) ? (int)$args['id'] : (int) qp($request, 'id', 0);
    $sesion_id   = isset($args['sesion_id']) ? (int)$args['sesion_id'] : (int) qp($request, 'sesion_id', 0);

    if (!$precorte_id && $sesion_id) {
      $s = $db->prepare("SELECT id FROM selemti.precorte WHERE sesion_id=:sid ORDER BY id DESC LIMIT 1");
      $s->execute([':sid'=>$sesion_id]);
      $precorte_id = (int)($s->fetch()['id'] ?? 0);
    }
    if (!$precorte_id) return J($response, ['ok'=>false,'error'=>'precorte_not_found'], 404);

    $p = $db->prepare("SELECT sesion_id FROM selemti.precorte WHERE id=:id");
    $p->execute([':id'=>$precorte_id]);
    $rowP = $p->fetch();
    if(!$rowP) return J($response, ['ok'=>false,'error'=>'precorte_not_found'],404);
    $sid = (int)$rowP['sesion_id'];

    $sinfo = $db->prepare("SELECT opening_float FROM selemti.sesion_cajon WHERE id=:sid");
    $sinfo->execute([':sid'=>$sid]);
    $opening_float = (float)($sinfo->fetch()['opening_float'] ?? 0);

    // declarado
    $tEF = $db->prepare("SELECT COALESCE(SUM(subtotal),0)::numeric s FROM selemti.precorte_efectivo WHERE precorte_id=:id");
    $tEF->execute([':id'=>$precorte_id]);
    $decl_ef = (float)($tEF->fetch()['s'] ?? 0);

    $decl_credito = 0.0; $decl_debito = 0.0; $decl_transfer = 0.0;
    $hasOtros = !empty($db->query("SELECT to_regclass('selemti.precorte_otros') AS t")->fetch()['t']);
    if($hasOtros){
      $qot = $db->prepare("SELECT UPPER(tipo) AS tipo, COALESCE(SUM(monto),0)::numeric AS monto
                           FROM selemti.precorte_otros WHERE precorte_id=:id GROUP BY UPPER(tipo)");
      $qot->execute([':id'=>$precorte_id]);
      foreach($qot as $r){
        if ($r['tipo']==='CREDITO')  $decl_credito  = (float)$r['monto'];
        if ($r['tipo']==='DEBITO')   $decl_debito   = (float)$r['monto'];
        if ($r['tipo']==='TRANSFER') $decl_transfer = (float)$r['monto'];
      }
    }

    // sistema
    $vw = $db->prepare("SELECT * FROM selemti.vw_conciliacion_sesion WHERE sesion_id=:sid");
    $vw->execute([':sid'=>$sid]);
    $sysE=0;$sysC=0;$sysD=0;$sysT=0;
    if($r = $vw->fetch()){
      $sysE = (float)($r['sistema_efectivo_esperado'] ?? 0);
      $sysC = (float)($r['sys_credito'] ?? $r['sys_credit'] ?? $r['credit'] ?? 0);
      $sysD = (float)($r['sys_debito']  ?? $r['sys_debit']  ?? $r['debit']  ?? 0);
      $sysT = (float)($r['sys_transfer'] ?? $r['transfer'] ?? 0);
    }

    $data = [
      'efectivo'        => ['declarado'=>$decl_ef,      'sistema'=>$sysE],
      'tarjeta_credito' => ['declarado'=>$decl_credito, 'sistema'=>$sysC],
      'tarjeta_debito'  => ['declarado'=>$decl_debito,  'sistema'=>$sysD],
      'transferencias'  => ['declarado'=>$decl_transfer,'sistema'=>$sysT],
    ];

    return J($response, [
      'ok'=>true,
      'data'=>$data,
      'opening_float'=>$opening_float,
      'precorte_id'=>$precorte_id,
      'sesion_id'=>$sid
    ]);
  }

  /* ===== Legacy: update con denoms_json + declarado_* ===== */
  public static function updateLegacy(Request $request, Response $response, array $args = []) {
    $db = self::p();
    $precorte_id = isset($args['id']) ? (int)$args['id'] : (int) qp($request, 'id', 0);
    if (!$precorte_id) return J($response, ['ok'=>false,'error'=>'missing_id'], 400);

    $st = $db->prepare("SELECT id, sesion_id FROM selemti.precorte WHERE id=:id");
    $st->execute([':id'=>$precorte_id]);
    $row = $st->fetch();
    if (!$row) return J($response, ['ok'=>false,'error'=>'precorte_not_found'], 404);
    $sid = (int)$row['sesion_id'];

    $denoms_json   = (string) qp($request, 'denoms_json', '[]');
    $decl_credito  = (float) qp($request, 'declarado_credito', 0);
    $decl_debito   = (float) qp($request, 'declarado_debito', 0);
    $decl_transfer = (float) qp($request, 'declarado_transfer', 0);
    $notas         = (string) qp($request, 'notas', '');

    $denoms = json_decode($denoms_json, true);
    if (!is_array($denoms)) $denoms = [];

    $db->beginTransaction();
    try {
      // efectivo
      $db->prepare("DELETE FROM selemti.precorte_efectivo WHERE precorte_id=:id")->execute([':id'=>$precorte_id]);

      if (!empty($denoms)) {
        $insEF = $db->prepare("INSERT INTO selemti.precorte_efectivo (precorte_id,denominacion,cantidad) VALUES (:pid,:den,:qty)");
        foreach ($denoms as $r) {
          $den = $r['den'] ?? $r['denominacion'] ?? null;
          $qty = $r['qty'] ?? $r['cantidad'] ?? null;
          if ($den===null || $qty===null) continue;
          $insEF->execute([':pid'=>$precorte_id, ':den'=>$den, ':qty'=>$qty]);
        }
        $db->prepare("UPDATE selemti.precorte_efectivo SET subtotal = denominacion*cantidad WHERE precorte_id = :pid")
           ->execute([':pid'=>$precorte_id]);
      }

      // encabezado: declarado_efectivo y notas
      $db->prepare("
        UPDATE selemti.precorte
           SET declarado_efectivo = COALESCE((SELECT SUM(subtotal) FROM selemti.precorte_efectivo WHERE precorte_id = :pid),0),
               notas = NULLIF(TRIM(:notas), '')
         WHERE id = :pid
      ")->execute([':pid'=>$precorte_id, ':notas'=>$notas]);

      // otros (si existe tabla)
      $hasOtros = !empty($db->query("SELECT to_regclass('selemti.precorte_otros') AS t")->fetch()['t']);
      if ($hasOtros) {
        $db->prepare("DELETE FROM selemti.precorte_otros WHERE precorte_id=:id")->execute([':id'=>$precorte_id]);
        $insOT = $db->prepare("INSERT INTO selemti.precorte_otros (precorte_id,tipo,monto) VALUES (:pid,:tipo,:monto)");
        $map = ['CREDITO'=>$decl_credito,'DEBITO'=>$decl_debito,'TRANSFER'=>$decl_transfer];
        foreach ($map as $tipo=>$monto) {
          if ((float)$monto <= 0) continue;
          $insOT->execute([':pid'=>$precorte_id, ':tipo'=>$tipo, ':monto'=>$monto]);
        }
        $db->prepare("
          UPDATE selemti.precorte
             SET declarado_otros = COALESCE((SELECT SUM(monto) FROM selemti.precorte_otros WHERE precorte_id = :pid),0)
           WHERE id = :pid
        ")->execute([':pid'=>$precorte_id]);
      }

      $db->commit();
      return J($response, ['ok'=>true,'precorte_id'=>$precorte_id,'sesion_id'=>$sid]);
    } catch (\Throwable $e) {
      $db->rollBack();
      return J($response, ['ok'=>false,'error'=>'tx_failed','message'=>$e->getMessage()], 500);
    }
  }

  /* ===== Estatus (GET/SET) ===== */
  public static function statusGet(Request $request, Response $response, array $args) {
    $db = self::p();
    $id = isset($args['id']) ? (int)$args['id'] : (int) qp($request, 'id', 0);
    if (!$id) return J($response, ['ok'=>false,'error'=>'missing_id'], 400);

    $st = $db->prepare("SELECT id, estatus, creado_en FROM selemti.precorte WHERE id=:id");
    $st->execute([':id'=>$id]);
    $row = $st->fetch();

    return $row
      ? J($response, ['ok'=>true,'precorte_id'=>(int)$row['id'],'estatus'=>$row['estatus'],'creado_en'=>$row['creado_en']])
      : J($response, ['ok'=>false,'error'=>'precorte_not_found'],404);
  }

  public static function statusSet(Request $request, Response $response, array $args) {
    $db  = self::p();
    $id  = isset($args['id']) ? (int)$args['id'] : (int) qp($request, 'id', 0);
    $est = strtoupper((string) qp($request,'estatus',''));
    if (!$id)  return J($response, ['ok'=>false,'error'=>'missing_id'], 400);
    if (!in_array($est,['PENDIENTE','ENVIADO','APROBADO','RECHAZADO'], true))
      return J($response, ['ok'=>false,'error'=>'bad_status'], 400);

    $st = $db->prepare("UPDATE selemti.precorte SET estatus=:e WHERE id=:id RETURNING id, estatus");
    $st->execute([':e'=>$est, ':id'=>$id]);
    $row = $st->fetch();

    return $row
      ? J($response, ['ok'=>true,'precorte_id'=>(int)$row['id'],'estatus'=>$row['estatus']])
      : J($response, ['ok'=>false,'error'=>'precorte_not_found'],404);
  }

  /* ===== (opcional) Enviar ===== */
  public static function enviar(Request $request, Response $response, array $args) {
    $db = self::p();
    $id = isset($args['id']) ? (int)$args['id'] : 0;
    if (!$id) return J($response, ['ok'=>false,'error'=>'missing_id'], 400);
    $st = $db->prepare("UPDATE selemti.precorte SET estatus='ENVIADO' WHERE id=:id RETURNING id, estatus");
    $st->execute([':id'=>$id]);
    $row = $st->fetch();
    return $row ? J($response, ['ok'=>true,'precorte_id'=>$row['id'],'estatus'=>$row['estatus']])
                : J($response, ['ok'=>false,'error'=>'precorte_not_found'],404);
  }
}
