<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class CajasController {

  /** Resuelve PDO sin tocar tu core */
  private static function p(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    // 1) Intenta /api/config.php y luego /config.php (ambos ya existen en tu proyecto)
    $candidates = [
      __DIR__ . '/../config.php',   // /api/config.php
      __DIR__ . '/../../config.php' // /config.php
    ];
    foreach ($candidates as $c) {
      if (is_file($c)) {
        $r = require $c;
        if ($r instanceof PDO) { $pdo = $r; return $pdo; }
      }
    }

    // 2) Fallback a tu helper actual (que llama a Terrena\Core\Database::pdo())
    if (function_exists('pdo')) {
      $pdo = pdo();
      if ($pdo instanceof PDO) return $pdo;
    }

    throw new RuntimeException('No fue posible inicializar PDO en CajasController.');
  }

  /**
   * GET/POST /caja/cajas.php?date=YYYY-MM-DD
   * Respuesta compatible con tu JS legacy.
   */
  public static function cajas(Request $req, Response $res): Response {
    $pdo   = self::p();
    $today = (string) qp($req,'date', date('Y-m-d'));
    $t0 = $today . ' 00:00:00';
    $t1 = $today . ' 23:59:59';

    try {
      /* 1) Catálogo de terminales (todas) */
      $sqlTerm = "
        SELECT t.id, COALESCE(NULLIF(TRIM(t.name),''), 'Terminal '||t.id) AS name,
               NULLIF(TRIM(r.name),'') AS location
        FROM public.terminal t
        LEFT JOIN public.restaurant r ON 1=0
        ORDER BY t.id ASC
      ";
      $terms = $pdo->query($sqlTerm)->fetchAll();

      /* 2) Stmts reusables */
      $stSesion = $pdo->prepare("
        SELECT id, terminal_id, cajero_usuario_id, apertura_ts, cierre_ts, estatus,
               opening_float, closing_float
        FROM selemti.sesion_cajon
        WHERE terminal_id=:t
          AND (apertura_ts BETWEEN :t0 AND :t1 OR (cierre_ts IS NOT NULL AND cierre_ts BETWEEN :t0 AND :t1))
        ORDER BY apertura_ts DESC
        LIMIT 1
      ");

      $stSesionActiva = $pdo->prepare("
        SELECT id, terminal_id, cajero_usuario_id, apertura_ts, cierre_ts, estatus,
               opening_float, closing_float
        FROM selemti.sesion_cajon
        WHERE terminal_id=:t AND estatus='ACTIVA'
        ORDER BY apertura_ts DESC
        LIMIT 1
      ");

      $stPrec = $pdo->prepare("
        SELECT id, estatus
        FROM selemti.precorte
        WHERE sesion_id=:sid
        ORDER BY id DESC
        LIMIT 1
      ");

      $stVw = $pdo->prepare("
        SELECT *
        FROM selemti.vw_conciliacion_sesion
        WHERE sesion_id=:sid
      ");

      $out = [];

      foreach ($terms as $te) {
        $tid   = (int)$te['id'];
        $tname = (string)$te['name'];
        $loc   = $te['location'] ?? null;

        /* 3) ¿Sesión del día? */
        $stSesion->execute([':t'=>$tid, ':t0'=>$t0, ':t1'=>$t1]);
        $ses = $stSesion->fetch();

        if (!$ses) {
          // Fallback: última ACTIVA
          $stSesionActiva->execute([':t'=>$tid]);
          $ses = $stSesionActiva->fetch();
        }

        $assignedUser  = null;
        $assignedName  = null;
        $asignada      = false;
        $activa        = false;
        $stage         = 'LIBRE';
        $openingFloat  = 0.0;
        $closingFloat  = 0.0;
        $sales         = [
          'cash'=>0,'credit'=>0,'debit'=>0,'transfer'=>0,'custom'=>0,'gift'=>0,
          'terminal_total'=>0,'assigned_total'=>0
        ];
        $sesionPayload = null;
        $precorte      = null;
        $hasPost       = false;

        if ($ses) {
          $sid          = (int)$ses['id'];
          $assignedUser = (int)$ses['cajero_usuario_id'];
          $asignada     = $assignedUser > 0;
          $activa       = (string)$ses['estatus'] === 'ACTIVA';
          $stage        = $activa ? 'ACTIVA' : 'ASIGNADA';
          $openingFloat = (float)$ses['opening_float'];
          $closingFloat = (float)($ses['closing_float'] ?? 0);

          $sesionPayload = [
            'id'            => $sid,
            'apertura_ts'   => $ses['apertura_ts'],
            'cierre_ts'     => $ses['cierre_ts'],
            'estatus'       => $ses['estatus'],
            'opening_float' => $openingFloat,
            'closing_float' => $closingFloat,
          ];

          /* 4) Precorte */
          $stPrec->execute([':sid'=>$sid]);
          if ($pr = $stPrec->fetch()) {
            $precorte = ['id'=>(int)$pr['id'], 'estatus'=>$pr['estatus']];
            if (!$activa) $stage = 'LISTO_PARA_CORTE';
          }

          /* 5) Vista de conciliación (ventas) */
          $stVw->execute([':sid'=>$sid]);
          if ($vw = $stVw->fetch()) {
            $cash     = (float)($vw['sys_cash']     ?? $vw['cash']     ?? 0);
            $credit   = (float)($vw['sys_credito']  ?? $vw['sys_credit'] ?? $vw['credit'] ?? 0);
            $debit    = (float)($vw['sys_debito']   ?? $vw['sys_debit']  ?? $vw['debit']  ?? 0);
            $transfer = (float)($vw['sys_transfer'] ?? $vw['transfer'] ?? 0);
            $custom   = (float)($vw['sys_custom']   ?? $vw['custom']   ?? 0);
            $gift     = (float)($vw['sys_gift']     ?? 0);

            $sales['cash']     = $cash;
            $sales['credit']   = $credit;
            $sales['debit']    = $debit;
            $sales['transfer'] = $transfer;
            $sales['custom']   = $custom;
            $sales['gift']     = $gift;

            $sales['terminal_total'] = $cash + $credit + $debit + $transfer + $custom + $gift;
            $sales['assigned_total'] = $sales['terminal_total'];
          }

          $hasPost = false;
        }

        $out[] = [
          'id'              => $tid,
          'name'            => $tname,
          'location'        => $loc,
          'assigned_user'   => $assignedUser,
          'assigned_name'   => $assignedName,
          'status'          => ['asignada'=>$asignada, 'activa'=>$activa],
          'stage'           => $stage,
          'window'          => ['t0'=>$t0, 't1'=>$t1, 'day'=>$today],
          'opening_balance' => $openingFloat,
          'current_balance' => $closingFloat,
          'sales'           => $sales,
          'sesion'          => $sesionPayload,
          'precorte'        => $precorte,
          'has_postcorte'   => $hasPost
        ];
      }

      return J($res, ['ok'=>true, 'date'=>$today, 'terminals'=>$out]);

    } catch (\Throwable $e) {
      return J($res, ['ok'=>false,'error'=>$e->getMessage()], 500);
    }
  }

  /** /caja/cajas_debug.php */
  public static function cajasDebug(Request $req, Response $res): Response {
    return self::cajas($req, $res);
  }
}
