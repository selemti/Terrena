// js/caja/main.js
import { cargarTabla } from './mainTable.js';
import { bindModalButtons, abrirWizard } from './wizard.js';
import { toast } from './helpers.js';

// Exponer para compatibilidad con onclick="abrirWizard(event)"
window.abrirWizard = abrirWizard;

if (!window.__CAJA_BOOTED__) {
  window.__CAJA_BOOTED__ = true;
  document.addEventListener('DOMContentLoaded', () => {
    // OJO: sin delegado de clicks aquí (evita duplicados)
    bindModalButtons();
    cargarTabla().catch(e => {
      console.error(e);
      toast(e.message || 'Error cargando tabla', 'err', 9000, 'Error');
    });
  });
} else {
  console.debug('[caja] ya inicializado, se ignora duplicado');
}
