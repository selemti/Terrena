Terrena Slim API (módulo de Cortes)
===================================

Coloca el contenido de esta carpeta dentro de `Terrena/api/` de tu proyecto.

Estructura:
- api/index.php
- api/.htaccess
- api/src/helpers.php
- api/src/db.php
- api/src/controllers/PrecortesController.php
- api/src/controllers/ConciliacionController.php
- api/src/routes/precortes.php
- api/src/routes/conciliacion.php
- api/src/routes/legacy.php

Notas:
- Acepta GET y POST en rutas clave para pruebas.
- Usa vistas: `selemti.vw_conciliacion_sesion`, `selemti.vw_sesion_retiros`, `selemti.vw_sesion_reembolsos_efectivo`.
- Umbral fijo = 10 MXN (se puede mover a BD).
- Preflight cuenta tickets abiertos en la **ventana** de la sesión (mismo terminal/usuario, create_date >= apertura_ts).