<?php
use Slim\App;
use Controllers\PrecortesController;

return function (App $app, PDO $pdo) {

  $controller = new PrecortesController($pdo);

  // Diseño nuevo
  $app->map(['GET','POST'], '/precortes/{sesion_id:[0-9]+}',           [$controller, 'upsert']);
  $app->map(['GET','POST'], '/precortes/{sesion_id:[0-9]+}/resumen',    [$controller, 'resumen']);
  $app->get('/precortes/{sesion_id:[0-9]+}/status',                     [$controller, 'statusGet']);
  $app->map(['POST','PATCH'], '/precortes/{sesion_id:[0-9]+}/status',   [$controller, 'statusSet']);

  // Legacy alias
  $app->map(['GET','POST'], '/sprecorte/preflight[/{sesion_id:[0-9]+}]',[$controller, 'preflight']);
  $app->map(['GET','POST'], '/sprecorte/totales[/{sesion_id:[0-9]+}]',  [$controller, 'resumen']);
  $app->map(['GET','POST'], '/sprecorte/create[/{sesion_id:[0-9]+}]',   [$controller, 'upsert']);
  $app->map(['GET','POST'], '/sprecorte/update[/{sesion_id:[0-9]+}]',   [$controller, 'upsert']);
};