<?php
use Slim\App;

return function (App $app, PDO $pdo) {
  // Aquí puedes mapear otros endpoints legacy si los necesitas.
};