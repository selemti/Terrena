<?php
use Slim\App;
use Controllers\ConciliacionController;

return function (App $app, PDO $pdo) {
  $controller = new ConciliacionController($pdo);
  $app->get('/conciliacion/{sesion_id:[0-9]+}', [$controller, 'get']);
};