<?php
declare(strict_types=1);

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

/** Read JSON body or query string (accept GET/POST for testing) */
function in_data(Request $request): array {
  $data = [];
  $contentType = $request->getHeaderLine('Content-Type');
  if (stripos($contentType, 'application/json') !== false) {
    $raw = (string) $request->getBody();
    if ($raw !== '') {
      $tmp = json_decode($raw, true);
      if (json_last_error() === JSON_ERROR_NONE) {
        $data = $tmp;
      }
    }
  }
  // Merge with POST/GET
  $data = array_merge($request->getParsedBody() ?: [], $request->getQueryParams() ?: [], $data ?: []);
  return is_array($data) ? $data : [];
}

function out_json(Response $response, array $payload, int $status = 200): Response {
  $response->getBody()->write(json_encode($payload, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES));
  return $response->withHeader('Content-Type','application/json')->withStatus($status);
}

function get_int($arr, $key, $default = null) {
  if (!is_array($arr)) return $default;
  if (!array_key_exists($key, $arr)) return $default;
  return is_numeric($arr[$key]) ? (int)$arr[$key] : $default;
}

function get_num($arr, $key, $default = 0.0) {
  if (!is_array($arr)) return $default;
  if (!array_key_exists($key, $arr)) return $default;
  return is_numeric($arr[$key]) ? (float)$arr[$key] : $default;
}

function get_str($arr, $key, $default = null) {
  if (!is_array($arr)) return $default;
  if (!array_key_exists($key, $arr)) return $default;
  return is_string($arr[$key]) ? trim($arr[$key]) : (is_numeric($arr[$key]) ? strval($arr[$key]) : $default);
}