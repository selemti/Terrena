<?php
declare(strict_types=1);

namespace Controllers;

use PDO;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class ConciliacionController {

  private PDO $db;

  public function __construct(PDO $pdo) {
    $this->db = $pdo;
  }

  public function get(Request $request, Response $response, array $args): Response {
    $sesion_id = isset($args['sesion_id']) ? (int)$args['sesion_id'] : 0;
    if (!$sesion_id) return out_json($response, ['ok'=>false,'error'=>'missing_param','param'=>'sesion_id'], 400);

    $sql = "SELECT * FROM selemti.vw_conciliacion_sesion WHERE sesion_id = :sid";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([':sid'=>$sesion_id]);
    $row = $stmt->fetch();

    if (!$row) return out_json($response, ['ok'=>false,'error'=>'not_found'], 404);

    return out_json($response, ['ok'=>true, 'data'=>$row]);
  }
}