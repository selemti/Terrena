<?php
declare(strict_types=1);

namespace Controllers;

use PDO;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class PrecortesController {

  private PDO $db;
  private float $umbral = 10.0; // umbral fijo

  public function __construct(PDO $pdo) {
    $this->db = $pdo;
  }

  public function preflight(Request $request, Response $response, array $args): Response {
    $data = in_data($request);
    $sesion_id = isset($args['sesion_id']) ? (int)$args['sesion_id'] : get_int($data, 'sesion_id');
    if (!$sesion_id) return out_json($response, ['ok'=>false,'error'=>'missing_param','param'=>'sesion_id'], 400);

    $ses = $this->getSesion($sesion_id);
    if (!$ses) return out_json($response, ['ok'=>false,'error'=>'sesion_not_found'], 404);

    $open = $this->countOpenTickets($sesion_id);
    $payload = [
      'ok' => $open === 0,
      'sesion' => ['id'=>$sesion_id, 'terminal_id'=>$ses['terminal_id'], 'cajero_usuario_id'=>$ses['cajero_usuario_id']],
      'open_tickets' => $open,
      'blocking' => $open > 0,
      'umbral' => $this->umbral,
    ];
    return out_json($response, $payload);
  }

  public function upsert(Request $request, Response $response, array $args): Response {
    $data = in_data($request);
    $sesion_id = isset($args['sesion_id']) ? (int)$args['sesion_id'] : get_int($data, 'sesion_id');
    if (!$sesion_id) return out_json($response, ['ok'=>false,'error'=>'missing_param','param'=>'sesion_id'], 400);

    if ($this->countOpenTickets($sesion_id) > 0) {
      return out_json($response, ['ok'=>false,'error'=>'tickets_open','message'=>'Cierre los tickets abiertos en el POS.'], 409);
    }

    $efectivo        = get_num($data, 'efectivo', null);
    $efectivoDetalle = $data['efectivo_detalle'] ?? null;
    $otros           = $data['otros'] ?? [];

    $this->db->beginTransaction();
    try {
      // create/reuse header
      $stmt = $this->db->prepare("SELECT id FROM selemti.precorte WHERE sesion_id = :sid ORDER BY id DESC LIMIT 1");
      $stmt->execute([':sid'=>$sesion_id]);
      $precorte = $stmt->fetchColumn();
      if (!$precorte) {
        $stmt = $this->db->prepare("INSERT INTO selemti.precorte(sesion_id) VALUES (:sid) RETURNING id");
        $stmt->execute([':sid'=>$sesion_id]);
        $precorte = (int)$stmt->fetchColumn();
      }

      if ($efectivo !== null) {
        $this->db->prepare("UPDATE selemti.precorte SET declarado_efectivo = :e WHERE id = :pid")
          ->execute([':e'=>$efectivo, ':pid'=>$precorte]);
      }

      if (is_array($efectivoDetalle)) {
        $this->db->prepare("DELETE FROM selemti.precorte_efectivo WHERE precorte_id = :pid")
          ->execute([':pid'=>$precorte]);
        $ins = $this->db->prepare("INSERT INTO selemti.precorte_efectivo(precorte_id, denominacion, cantidad) VALUES (:pid,:den,:cant)");
        foreach ($efectivoDetalle as $row) {
          $den = is_numeric($row['denominacion'] ?? null) ? (float)$row['denominacion'] : null;
          $cnt = is_numeric($row['cantidad'] ?? null) ? (int)$row['cantidad'] : null;
          if ($den !== null && $cnt !== null && $cnt > 0) {
            $ins->execute([':pid'=>$precorte, ':den'=>$den, ':cant'=>$cnt]);
          }
        }
        // totals
        $this->db->exec("UPDATE selemti.precorte_efectivo SET subtotal = denominacion*cantidad WHERE precorte_id = {$precorte}");
        $this->db->exec("UPDATE selemti.precorte SET declarado_efectivo = COALESCE((SELECT SUM(subtotal) FROM selemti.precorte_efectivo WHERE precorte_id = {$precorte}),0) WHERE id = {$precorte}");
      }

      if (is_array($otros)) {
        // only if table exists
        $hasOtros = false;
        $chk = $this->db->query("SELECT to_regclass('selemti.precorte_otros') AS t")->fetch();
        $hasOtros = !empty($chk['t']);
        if ($hasOtros) {
          $this->db->prepare("DELETE FROM selemti.precorte_otros WHERE precorte_id=:pid")->execute([':pid'=>$precorte]);
          $ins2 = $this->db->prepare("INSERT INTO selemti.precorte_otros(precorte_id, tipo, monto, referencia, evidencia_url, notas) VALUES (:pid,:tipo,:monto,:ref,:url,:notas)");
          foreach ($otros as $o) {
            $tipo = strtoupper(trim((string)($o['tipo'] ?? '')));
            $monto = is_numeric($o['monto'] ?? null) ? (float)$o['monto'] : 0.0;
            if ($monto <= 0) continue;
            $ref = isset($o['referencia']) ? (string)$o['referencia'] : null;
            $url = isset($o['evidencia_url']) ? (string)$o['evidencia_url'] : null;
            $nt  = isset($o['notas']) ? (string)$o['notas'] : null;
            $ins2->execute([':pid'=>$precorte, ':tipo'=>$tipo, ':monto'=>$monto, ':ref'=>$ref, ':url'=>$url, ':notas'=>$nt]);
          }
          $this->db->exec("UPDATE selemti.precorte SET declarado_otros = COALESCE((SELECT SUM(monto) FROM selemti.precorte_otros WHERE precorte_id = {$precorte}),0) WHERE id = {$precorte}");
        }
      }

      $this->db->commit();
      return out_json($response, ['ok'=>true, 'precorte_id'=>$precorte, 'sesion_id'=>$sesion_id]);
    } catch (\Throwable $e) {
      $this->db->rollBack();
      return out_json($response, ['ok'=>false, 'error'=>'exception', 'message'=>$e->getMessage()], 500);
    }
  }

  public function resumen(Request $request, Response $response, array $args): Response {
    $data = in_data($request);
    $sesion_id = isset($args['sesion_id']) ? (int)$args['sesion_id'] : get_int($data, 'sesion_id');
    if (!$sesion_id) return out_json($response, ['ok'=>false,'error'=>'missing_param','param':'sesion_id'], 400);

    $row = $this->fetchConciliacion($sesion_id);
    if (!$row) return out_json($response, ['ok'=>false,'error'=>'not_found'], 404);

    $sistema_tarjetas = (float)($row['sistema_no_efectivo'] ?? 0);
    $decl_tarjetas = (float)(($row['decl_credito'] ?? 0) + ($row['decl_debito'] ?? 0) + ($row['decl_transfer'] ?? 0) + ($row['decl_custom'] ?? 0) + ($row['decl_gift'] ?? 0));

    $payload = [
      'ok' => true,
      'sesion' => ['id'=>$sesion_id],
      'sistema' => [
        'cash'        => (float)($row['opening_float'] ?? 0) + (float)($row['sys_cash'] ?? 0) - (float)($row['retiros'] ?? 0) - (float)($row['reembolsos_efectivo'] ?? 0),
        'credit'      => (float)($row['sys_credito'] ?? 0),
        'debit'       => (float)($row['sys_debito'] ?? 0),
        'transfer'    => (float)($row['sys_transfer'] ?? 0),
        'custom'      => (float)($row['sys_custom'] ?? 0),
        'gift'        => (float)($row['sys_gift'] ?? 0),
        'retiros'     => (float)($row['retiros'] ?? 0),
        'refunds_cash'=> (float)($row['reembolsos_efectivo'] ?? 0),
        'sistema_efectivo_esperado' => (float)($row['sistema_efectivo_esperado'] ?? 0),
        'sistema_tarjetas'          => $sistema_tarjetas,
      ],
      'declarado' => [
        'efectivo' => (float)($row['declarado_efectivo'] ?? 0),
        'otros'    => [
          'CREDITO'  => (float)($row['decl_credito'] ?? 0),
          'DEBITO'   => (float)($row['decl_debito'] ?? 0),
          'TRANSFER' => (float)($row['decl_transfer'] ?? 0),
          'CUSTOM'   => (float)($row['decl_custom'] ?? 0),
          'GIFT_CERT'=> (float)($row['decl_gift'] ?? 0),
        ]
      ],
    ];
    $payload['dif'] = [
      'efectivo' => round($payload['declarado']['efectivo'] - (float)($row['sistema_efectivo_esperado'] ?? 0), 2),
      'tarjetas' => round($decl_tarjetas - $sistema_tarjetas, 2),
    ];
    $payload['umbral'] = $this->umbral;
    $payload['veredictos'] = [
      'efectivo' => abs($payload['dif']['efectivo']) <= $this->umbral ? 'DENTRO_UMBRAL' : ($payload['dif']['efectivo'] == 0 ? 'CUADRA' : ($payload['dif']['efectivo'] > 0 ? 'A_FAVOR' : 'EN_CONTRA')),
      'tarjetas' => $payload['dif']['tarjetas'] == 0 ? 'CUADRA' : ($payload['dif']['tarjetas'] > 0 ? 'A_FAVOR' : 'EN_CONTRA'),
    ];

    return out_json($response, $payload);
  }

  public function statusGet(Request $request, Response $response, array $args): Response {
    $data = in_data($request);
    $sesion_id = isset($args['sesion_id']) ? (int)$args['sesion_id'] : get_int($data, 'sesion_id');
    if (!$sesion_id) return out_json($response, ['ok'=>false,'error'=>'missing_param','param'=>'sesion_id'], 400);

    $stmt = $this->db->prepare("SELECT id, estatus, creado_en FROM selemti.precorte WHERE sesion_id = :sid ORDER BY id DESC LIMIT 1");
    $stmt->execute([':sid'=>$sesion_id]);
    $row = $stmt->fetch();
    if (!$row) return out_json($response, ['ok'=>true, 'estatus'=>'SIN_PRECORTE']);

    return out_json($response, ['ok'=>true, 'precorte_id'=>(int)$row['id'], 'estatus'=>$row['estatus'], 'creado_en'=>$row['creado_en']]);
  }

  public function statusSet(Request $request, Response $response, array $args): Response {
    $data = in_data($request);
    $sesion_id = isset($args['sesion_id']) ? (int)$args['sesion_id'] : get_int($data, 'sesion_id');
    $estatus   = strtoupper(get_str($data, 'estatus', ''));
    if (!$sesion_id) return out_json($response, ['ok'=>false,'error'=>'missing_param','param'=>'sesion_id'], 400);
    if (!in_array($estatus, ['PENDIENTE','ENVIADO','APROBADO','RECHAZADO'], true)) {
      return out_json($response, ['ok'=>false, 'error'=>'invalid_status'], 400);
    }
    $stmt = $this->db->prepare("UPDATE selemti.precorte SET estatus = :st WHERE id = (SELECT id FROM selemti.precorte WHERE sesion_id = :sid ORDER BY id DESC LIMIT 1)");
    $stmt->execute([':st'=>$estatus, ':sid'=>$sesion_id]);
    return out_json($response, ['ok'=>true, 'sesion_id'=>$sesion_id, 'estatus'=>$estatus]);
  }

  private function countOpenTickets(int $sesion_id): int {
    $sql = "
      WITH s AS (
        SELECT id, terminal_id, cajero_usuario_id, apertura_ts, COALESCE(cierre_ts, now()) AS fin
        FROM selemti.sesion_cajon WHERE id = :sid
      )
      SELECT COUNT(*)
      FROM public.ticket t, s
      WHERE t.terminal_id = s.terminal_id
        AND t.owner_id    = s.cajero_usuario_id
        AND t.create_date >= s.apertura_ts
        AND t.create_date <  s.fin
        AND COALESCE(t.paid,false) = false
        AND COALESCE(t.voided,false) = false
        AND COALESCE(t.settled,false) = false
    ";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([':sid'=>$sesion_id]);
    return (int)$stmt->fetchColumn();
  }

  private function getSesion(int $sesion_id): ?array {
    $stmt = $this->db->prepare("SELECT * FROM selemti.sesion_cajon WHERE id = :sid");
    $stmt->execute([':sid'=>$sesion_id]);
    $row = $stmt->fetch();
    return $row ?: null;
  }

  private function fetchConciliacion(int $sesion_id): ?array {
    $sql = "SELECT c.*,
                   COALESCE(r.retiros,0) AS retiros,
                   COALESCE(cr.reembolsos_efectivo,0) AS reembolsos_efectivo
            FROM selemti.vw_conciliacion_sesion c
            LEFT JOIN selemti.vw_sesion_retiros r ON r.sesion_id = c.sesion_id
            LEFT JOIN selemti.vw_sesion_reembolsos_efectivo cr ON cr.sesion_id = c.sesion_id
            WHERE c.sesion_id = :sid";
    $stmt = $this->db->prepare($sql);
    $stmt->execute([':sid'=>$sesion_id]);
    $row = $stmt->fetch();
    return $row ?: null;
  }
}