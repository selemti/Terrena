<?php
declare(strict_types=1);

require __DIR__ . '/../vendor/autoload.php';

// Intenta incluir config.php (arriba) si existe
$cfgCandidates = [__DIR__ . '/../config.php', __DIR__ . '/config.php'];
foreach ($cfgCandidates as $c) { if (is_file($c)) { include_once $c; } }

require __DIR__ . '/src/helpers.php';
require __DIR__ . '/src/db.php';

use Slim\Factory\AppFactory;
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

$app = AppFactory::create();

// Si tu Slim corre en /terrena/Terrena/api, descomenta:
// $app->setBasePath('/terrena/Terrena/api');

// Middleware básicos
$app->addBodyParsingMiddleware();
$app->addRoutingMiddleware();
$app->addErrorMiddleware(true, true, true);

// Health
$app->get('/health', function(Request $req, Response $res){
  return out_json($res, ['ok'=>true,'ts'=>date('c')]);
});

$pdo = DB::pdo();

// Rutas
(require __DIR__ . '/src/routes/precortes.php')($app, $pdo);
(require __DIR__ . '/src/routes/conciliacion.php')($app, $pdo);
(require __DIR__ . '/src/routes/legacy.php')($app, $pdo);

$app->run();