<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class PreCorteController {
    public static function preflight(Request $request, Response $response) {
        $sid = qp($request, 'sesion_id');
        
        if(!$sid) {
            return J($response, ['ok' => false, 'error' => 'missing_params (sesion_id)'], 400);
        }

        // Detecta terminal de la sesión
        $s = pdo()->prepare("SELECT terminal_id FROM selemti.sesion_cajon WHERE id = :id");
        $s->execute([':id' => $sid]);
        $ses = $s->fetch();
        
        if(!$ses) {
            return J($response, ['ok' => false, 'error' => 'sesion_not_found'], 404);
        }

        // Tickets abiertos
        $abiertos = 0;
        try {
            $tq = pdo()->prepare("
                SELECT count(*)::int AS n
                FROM public.ticket t
                WHERE t.terminal_id = :tid
                    AND COALESCE(t.voided, false) = false
                    AND t.closing_date IS NULL
            ");
            $tq->execute([':tid' => $ses['terminal_id']]);
            $abiertos = (int)$tq->fetch()['n'];
        } catch(Throwable $e) {
            $abiertos = 0;
        }
        
        $bloqueo = $abiertos > 0;
        return $bloqueo
            ? J($response, ['ok' => false, 'error' => 'tickets_open', 'tickets' => $abiertos], 409)
            : J($response, ['ok' => true, 'tickets_abiertos' => $abiertos, 'bloqueo' => false]);
    }

    public static function createOrUpdate(Request $request, Response $response) {
        $sid = qp($request, 'sesion_id');
        $ef = qp($request, 'efectivo_detalle', []);
        $ot = qp($request, 'otros', []);
        
        if(!$sid) {
            return J($response, ['ok' => false, 'error' => 'missing_params (sesion_id)'], 400);
        }

        pdo()->beginTransaction();
        try {
            $st = pdo()->prepare("SELECT id FROM selemti.precorte WHERE sesion_id = :sid ORDER BY id DESC LIMIT 1");
            $st->execute([':sid' => $sid]);
            $precorte_id = $st->fetch()['id'] ?? null;
            
            if(!$precorte_id) {
                $ins = pdo()->prepare("INSERT INTO selemti.precorte (sesion_id, estatus) VALUES (:sid, 'PENDIENTE') RETURNING id");
                $ins->execute([':sid' => $sid]);
                $precorte_id = (int)$ins->fetch()['id'];
            }

            // efectivo_detalle
            if (is_array($ef)) {
                pdo()->prepare("DELETE FROM selemti.precorte_efectivo WHERE precorte_id = :id")->execute([':id' => $precorte_id]);
                $insEF = pdo()->prepare("
                    INSERT INTO selemti.precorte_efectivo (precorte_id, denominacion, cantidad)
                    VALUES (:pid, :den, :qty)
                ");
                
                foreach($ef as $row) {
                    if (!isset($row['denominacion'], $row['cantidad'])) continue;
                    $insEF->execute([':pid' => $precorte_id, ':den' => $row['denominacion'], ':qty' => $row['cantidad']]);
                }
            }

            // otros
            $hasOtros = false;
            try {
                $x = pdo()->query("SELECT to_regclass('selemti.precorte_otros') AS t")->fetch();
                $hasOtros = !empty($x['t']);
            } catch(Throwable $e) {}
            
            if ($hasOtros && is_array($ot)) {
                pdo()->prepare("DELETE FROM selemti.precorte_otros WHERE precorte_id = :id")->execute([':id' => $precorte_id]);
                $insOT = pdo()->prepare("
                    INSERT INTO selemti.precorte_otros (precorte_id, tipo, monto, referencia, evidencia_url, notas)
                    VALUES (:pid, :tipo, :monto, :ref, :url, :notas)
                ");
                
                foreach($ot as $row) {
                    if (!isset($row['tipo'], $row['monto'])) continue;
                    $insOT->execute([
                        ':pid' => $precorte_id, ':tipo' => $row['tipo'], ':monto' => $row['monto'],
                        ':ref' => $row['referencia'] ?? null, ':url' => $row['evidencia_url'] ?? null, ':notas' => $row['notas'] ?? null
                    ]);
                }
            }

            // Totales declarados
            $tEF = pdo()->prepare("SELECT COALESCE(SUM(subtotal), 0)::numeric AS s FROM selemti.precorte_efectivo WHERE precorte_id = :id");
            $tEF->execute([':id' => $precorte_id]);
            $declarado_ef = (float)$tEF->fetch()['s'];

            $declarado_ot = 0.0;
            if ($hasOtros) {
                $tOT = pdo()->prepare("SELECT COALESCE(SUM(monto), 0)::numeric AS s FROM selemti.precorte_otros WHERE precorte_id = :id");
                $tOT->execute([':id' => $precorte_id]);
                $declarado_ot = (float)$tOT->fetch()['s'];
            } else if (is_array($ot)) {
                foreach($ot as $row) {
                    if(isset($row['monto'])) $declarado_ot += (float)$row['monto'];
                }
            }

            pdo()->commit();
            return J($response, [
                'ok' => true,
                'precorte_id' => $precorte_id,
                'estatus' => 'PENDIENTE',
                'totales' => ['efectivo' => $declarado_ef, 'otros' => $declarado_ot]
            ]);
        } catch(Throwable $e) {
            pdo()->rollBack();
            return J($response, ['ok' => false, 'error' => 'tx_failed', 'message' => $e->getMessage()], 500);
        }
    }

    public static function enviar(Request $request, Response $response, array $args) {
        $id = (int)$args['id'];
        $st = pdo()->prepare("UPDATE selemti.precorte SET estatus = 'ENVIADO' WHERE id = :id RETURNING id, estatus");
        $st->execute([':id' => $id]);
        $row = $st->fetch();
        
        return $row ? J($response, ['ok' => true, 'precorte_id' => $row['id'], 'estatus' => $row['estatus']])
                   : J($response, ['ok' => false, 'error' => 'precorte_not_found'], 404);
    }

    public static function resumen(Request $request, Response $response, array $args) {
        $id = (int)$args['id'];

        // Sesión del precorte
        $p = pdo()->prepare("SELECT sesion_id FROM selemti.precorte WHERE id = :id");
        $p->execute([':id' => $id]);
        $prec = $p->fetch();
        
        if(!$prec) {
            return J($response, ['ok' => false, 'error' => 'precorte_not_found'], 404);
        }

        $sid = (int)$prec['sesion_id'];

        // Declarado
        $tEF = pdo()->prepare("SELECT COALESCE(SUM(subtotal), 0)::numeric AS s FROM selemti.precorte_efectivo WHERE precorte_id = :id");
        $tEF->execute([':id' => $id]);
        $decl_ef = (float)$tEF->fetch()['s'];

        $decl_ot = ['CREDITO' => 0, 'DEBITO' => 0, 'TRANSFER' => 0, 'CUSTOM' => 0];
        try {
            $has = pdo()->query("SELECT to_regclass('selemti.precorte_otros') AS t")->fetch();
            if(!empty($has['t'])) {
                $qot = pdo()->prepare("SELECT tipo, COALESCE(SUM(monto), 0)::numeric AS monto FROM selemti.precorte_otros WHERE precorte_id = :id GROUP BY tipo");
                $qot->execute([':id' => $id]);
                foreach($qot as $row) {
                    $decl_ot[$row['tipo']] = (float)$row['monto'];
                }
            }
        } catch(Throwable $e) {}

        // Sistema (vista de conciliación)
        $sys = [
            'cash' => 0, 'credit' => 0, 'debit' => 0, 'transfer' => 0, 'custom' => 0, 'retiros' => 0, 'refunds_cash' => 0,
            'sistema_efectivo_esperado' => 0, 'sistema_tarjetas' => 0
        ];
        
        try {
            $v = pdo()->prepare("SELECT * FROM selemti.vw_conciliacion_sesion WHERE sesion_id = :sid");
            $v->execute([':sid' => $sid]);
            
            if ($row = $v->fetch()) {
                $sys['cash'] = (float)($row['sys_cash'] ?? $row['cash'] ?? 0);
                $sys['credit'] = (float)($row['sys_credit'] ?? 0);
                $sys['debit'] = (float)($row['sys_debit'] ?? 0);
                $sys['transfer'] = (float)($row['sys_transfer'] ?? 0);
                $sys['custom'] = (float)($row['sys_custom'] ?? 0);
                $sys['retiros'] = (float)($row['retiros'] ?? 0);
                $sys['refunds_cash'] = (float)($row['refunds_cash'] ?? 0);
                $sys['sistema_efectivo_esperado'] = (float)($row['sistema_efectivo_esperado'] ?? 0);
                $sys['sistema_tarjetas'] = (float)(
                    $row['sys_credit'] + $row['sys_debit'] + ($row['sys_transfer'] ?? 0) + ($row['sys_custom'] ?? 0)
                );
            }
        } catch(Throwable $e) {}

        $dif = [
            'efectivo' => $decl_ef - $sys['sistema_efectivo_esperado'],
            'tarjetas' => array_sum($decl_ot) - $sys['sistema_tarjetas']
        ];

        return J($response, [
            'ok' => true,
            'sesion' => ['id' => $sid],
            'sistema' => $sys,
            'declarado' => ['efectivo' => $decl_ef, 'otros' => $decl_ot],
            'dif' => $dif
        ]);
    }
}