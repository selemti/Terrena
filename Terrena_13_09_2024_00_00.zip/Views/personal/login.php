<?php $title='Login'; ?>
<div class="row justify-content-center mt-4">
  <div class="col-12 col-sm-10 col-md-6 col-lg-4">
    <div class="card-vo p-4">
      <h5 class="card-title mb-3"><i class="fa-solid fa-right-to-bracket"></i> Iniciar sesión</h5>
      <input class="form-control form-control-sm mb-2" placeholder="Usuario">
      <input class="form-control form-control-sm mb-2" placeholder="Contraseña" type="password">
      <button class="btn btn-sm text-white w-100" style="background:var(--green-dark)">Entrar</button>
    </div>
  </div>
</div>
