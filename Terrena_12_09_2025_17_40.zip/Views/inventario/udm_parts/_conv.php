<div class="alert alert-info small">Equivalencias: ej. 1 L = 1000 ML; 1 CAJA12 = 12 PZA.</div>
<table class="table table-sm align-middle">
  <thead><tr><th>Desde</th><th class="text-end">Factor</th><th>Hacia</th><th class="text-end">Acciones</th></tr></thead>
  <tbody>
    <tr><td>L</td><td class="text-end">1000</td><td>ML</td><td class="text-end"><button class="btn btn-sm btn-outline-secondary">Editar</button></td></tr>
    <tr><td>CAJA12</td><td class="text-end">12</td><td>PZA</td><td class="text-end"><button class="btn btn-sm btn-outline-secondary">Editar</button></td></tr>
    <tr><td>KG</td><td class="text-end">1000</td><td>G</td><td class="text-end"><button class="btn btn-sm btn-outline-secondary">Editar</button></td></tr>
  </tbody>
</table>
