import { BASE, DENOMS, MXN, api } from './config.js';
import { $, GET, POST_FORM, toast } from './helpers.js';
import { els, state } from './state.js';

export function setStep(n){
  state.step = n;
  if (!els.modal) return;
  if (els.step1) els.step1.classList.toggle('d-none', n!==1);
  if (els.step2) els.step2.classList.toggle('d-none', n!==2);
  if (els.step3) els.step3.classList.toggle('d-none', n!==3);
  if (els.stepBar){
    const pct = n===1?33:(n===2?66:100);
    els.stepBar.style.width = pct+'%';
    els.stepBar.setAttribute('aria-valuenow', String(pct));
  }
  if (els.btnGuardarPrecorte) els.btnGuardarPrecorte.classList.toggle('d-none', n!==1);
  if (els.btnContinuarConc)   els.btnContinuarConc.classList.toggle('d-none', n!==1);
  if (els.btnIrPostcorte)     els.btnIrPostcorte.classList.toggle('d-none', n!==2);
  if (els.btnCerrarSesion)    els.btnCerrarSesion.classList.toggle('d-none', n!==3);
}

export function bindDenoms(){
  if (!els.tablaDenomsBody) return;
  els.tablaDenomsBody.innerHTML = '';
  state.denoms.clear();
  DENOMS.forEach(den=>{
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>$${den}</td>
      <td><input type="number" min="0" step="1" class="form-control form-control-sm cz-qty" data-denom="${den}" value="0" inputmode="numeric"></td>
      <td class="text-end cz-amt" data-denom="${den}">${MXN.format(0)}</td>`;
    els.tablaDenomsBody.appendChild(tr);
  });
  els.tablaDenomsBody.querySelectorAll('.cz-qty').forEach(inp=>{
    inp.addEventListener('input',()=>{
      const denom = Number(inp.dataset.denom);
      const qty   = Math.max(0, parseInt(inp.value||'0',10) || 0);
      state.denoms.set(denom, qty);
      const amt = denom * qty;
      const cell= els.tablaDenomsBody.querySelector(`.cz-amt[data-denom="${denom}"]`);
      if (cell) cell.textContent = MXN.format(amt);
      recalcPaso1();
    });
    inp.addEventListener('blur',()=>{ if (inp.value==='') { inp.value='0'; inp.dispatchEvent(new Event('input')); }});
  });
}

export function recalcPaso1(){
  let totalEf = 0;
  state.denoms.forEach((qty,den)=> totalEf += den*qty);
  if (els.precorteTotal) els.precorteTotal.textContent = MXN.format(totalEf);

  const credito  = Number(els.declCredito?.value || 0);
  const debito   = Number(els.declDebito?.value  || 0);
  const transfer = Number(els.declTransfer?.value|| 0);

  const okDenoms = totalEf > 0;
  const okNE     = [credito,debito,transfer].every(v=> !Number.isNaN(v) && v>=0);

  if (els.btnGuardarPrecorte) els.btnGuardarPrecorte.disabled = !(okDenoms && okNE);
  if (els.btnContinuarConc)   els.btnContinuarConc.disabled   = !state.pasoGuardado;

  if (els.chipFondo) els.chipFondo.textContent = MXN.format(state.sesion.opening||0);
  if (els.efEsperadoInfo) els.efEsperadoInfo.textContent = MXN.format((state.sesion.opening||0));
}

// Fallback visual si no existe el modal real
function fallbackModal(html){
  let ov = document.getElementById('__debug_fallback_modal');
  if (!ov){
    ov = document.createElement('div');
    ov.id='__debug_fallback_modal';
    ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;display:flex;align-items:center;justify-content:center';
    ov.innerHTML = `
      <div style="background:#fff;max-width:720px;width:92%;border-radius:10px;box-shadow:0 10px 40px rgba(0,0,0,.25);overflow:hidden">
        <div style="padding:10px 14px;border-bottom:1px solid #eee;display:flex;align-items:center;gap:8px">
          <strong>Precorte</strong>
          <span style="margin-left:auto;cursor:pointer;font-weight:bold" id="__debug_fallback_close">×</span>
        </div>
        <div id="__debug_fallback_body" style="padding:14px;max-height:70vh;overflow:auto"></div>
      </div>`;
    document.body.appendChild(ov);
    ov.querySelector('#__debug_fallback_close').onclick=()=>ov.remove();
  }
  ov.querySelector('#__debug_fallback_body').innerHTML = html;
  ov.style.display='flex';
}

function ensureModalRefs(){
  const modal = document.querySelector('#modalPrecorte, #wizardPrecorte, .modal[data-role="precorte"]');
  els.modal = modal || null;
  if (!els.modal) return false;

  els.step1 = els.modal.querySelector('#step1, [data-step="1"]');
  els.step2 = els.modal.querySelector('#step2, [data-step="2"]');
  els.step3 = els.modal.querySelector('#step3, [data-step="3"]');
  els.stepBar = els.modal.querySelector('.progress-bar, [data-role="stepbar"]');

  els.btnGuardarPrecorte = els.modal.querySelector('#btnGuardarPrecorte, [data-action="guardar-precorte"]');
  els.btnContinuarConc   = els.modal.querySelector('#btnContinuarConc, [data-action="continuar-conc"]');
  els.btnSincronizarPOS  = els.modal.querySelector('#btnSincronizarPOS, [data-action="sincronizar-pos"]');
  els.btnIrPostcorte     = els.modal.querySelector('#btnIrPostcorte, [data-action="ir-postcorte"]');
  els.btnCerrarSesion    = els.modal.querySelector('#btnCerrarSesion, [data-action="cerrar-sesion"]');

  els.tablaDenomsBody = els.modal.querySelector('#tablaDenomsBody, [data-role="denoms-body"]');
  els.precorteTotal   = els.modal.querySelector('#precorteTotal, [data-role="precorte-total"]');
  els.declCredito     = els.modal.querySelector('#declCredito, [data-role="decl-credito"]');
  els.declDebito      = els.modal.querySelector('#declDebito, [data-role="decl-debito"]');
  els.declTransfer    = els.modal.querySelector('#declTransfer, [data-role="decl-transfer"]');
  els.notasPaso1      = els.modal.querySelector('#notasPaso1, [data-role="notas-paso1"]');
  els.chipFondo       = els.modal.querySelector('[data-role="chip-fondo"]');
  els.efEsperadoInfo  = els.modal.querySelector('[data-role="ef-esperado"]');
  els.concGrid        = els.modal.querySelector('#concGrid, [data-role="conc-grid"]');
  els.bannerFaltaCorte= els.modal.querySelector('[data-role="banner-falta-corte"]');

  els.inputPrecorteId = document.querySelector('#precorteId, [data-role="precorte-id"]');
  return true;
}

export async function abrirWizard(ev){
  ev?.preventDefault?.();

  // botón real (click en <i> también)
  const btn = (
    ev?.currentTarget?.closest?.('[data-caja-action="wizard"]') ||
    ev?.target?.closest?.('[data-caja-action="wizard"]')
  );
  if (!btn){ toast('No se pudo resolver el botón del wizard','err', 8000, 'UI'); return; }
  if (btn.__busy) return; btn.__busy = true;

  const d = (k)=> (btn.dataset && k in btn.dataset) ? btn.dataset[k] : btn.getAttribute?.(`data-${k}`);
  const store    = parseInt(d('store')||'0',10);
  const terminal = parseInt(d('terminal')||'0',10);
  const user     = parseInt(d('user')||'0',10);
  const bdate    = String(d('bdate')||'').trim();
  const opening  = Number(d('opening')||0);
  const sesion   = parseInt(d('sesion')||'0',10);   // ← opcional para preflight

  state.sesion = { store, terminal, user, bdate, opening };
  state.precorteId = null;
  state.pasoGuardado = false;

  if (!store || !terminal || !user || !bdate){
    toast('Faltan store/terminal/usuario','err', 12000, 'Datos incompletos', {sticky:true});
    btn.__busy = false; return;
  }

  try{
    // --- PRECHECK: si tenemos sesion_id, evitamos 409
    if (sesion){
      const pre = await GET(`${BASE}/api/sprecorte/preflight?sesion_id=${encodeURIComponent(sesion)}`);
      if (pre && pre.bloqueo){
        const n = pre.tickets || pre.tickets_abiertos || 0;
        toast(`No puedes iniciar precorte: hay ${n} ticket(s) abiertos en el POS.`, 'warn', 0, 'Bloqueado', {
          sticky:true,
          actions:[{ label:'Reintentar', onClick:({close})=>{ close(); abrirWizard({ currentTarget: btn }); }}]
        });
        return; // bloqueado
      }
    }

    // --- Iniciar precorte
    const payload = { bdate, store_id:store, terminal_id:terminal, user_id:user };
    const j = await POST_FORM(api.precorte_create(), payload);

    if (!j?.ok || !j?.precorte_id){
      toast('No se pudo iniciar precorte','err', 12000, 'Error', {sticky:true});
      return;
    }

    state.precorteId = j.precorte_id;
    els.inputPrecorteId && (els.inputPrecorteId.value = String(state.precorteId));

    // Abrir modal (o fallback)
    const modal = document.querySelector('#modalPrecorte, #wizardPrecorte, .modal[data-role="precorte"]');
    els.modal = modal || null;
    if (!els.modal){
      const ov = document.createElement('div');
      ov.style.cssText='position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99999;display:flex;align-items:center;justify-content:center';
      ov.innerHTML = `<div style="background:#fff;max-width:720px;width:92%;border-radius:10px;box-shadow:0 10px 40px rgba(0,0,0,.25);overflow:hidden">
        <div style="padding:10px 14px;border-bottom:1px solid #eee;display:flex;gap:8px">
          <strong>Precorte</strong><span style="margin-left:auto;cursor:pointer;font-weight:bold" id="__x">×</span>
        </div><div style="padding:14px;max-height:70vh;overflow:auto">
          Precorte iniciado <b>#${state.precorteId}</b>, pero no se encontró el modal real.
          Incluye <code>_wizard_modals.php</code> antes de los &lt;script&gt;.
        </div></div>`;
      document.body.appendChild(ov);
      ov.querySelector('#__x').onclick=()=>ov.remove();
      return;
    }

    // Preparar refs mínimas
    els.step1 = els.modal.querySelector('#step1,[data-step="1"]');
    els.step2 = els.modal.querySelector('#step2,[data-step="2"]');
    els.step3 = els.modal.querySelector('#step3,[data-step="3"]');
    els.stepBar = els.modal.querySelector('.progress-bar,[data-role="stepbar"]');
    els.btnGuardarPrecorte = els.modal.querySelector('#btnGuardarPrecorte,[data-action="guardar-precorte"]');
    els.btnContinuarConc   = els.modal.querySelector('#btnContinuarConc,[data-action="continuar-conc"]');
    els.btnSincronizarPOS  = els.modal.querySelector('#btnSincronizarPOS,[data-action="sincronizar-pos"]');
    els.btnIrPostcorte     = els.modal.querySelector('#btnIrPostcorte,[data-action="ir-postcorte"]');
    els.btnCerrarSesion    = els.modal.querySelector('#btnCerrarSesion,[data-action="cerrar-sesion"]');
    els.tablaDenomsBody    = els.modal.querySelector('#tablaDenomsBody,[data-role="denoms-body"]');
    els.precorteTotal      = els.modal.querySelector('#precorteTotal,[data-role="precorte-total"]');
    els.declCredito        = els.modal.querySelector('#declCredito,[data-role="decl-credito"]');
    els.declDebito         = els.modal.querySelector('#declDebito,[data-role="decl-debito"]');
    els.declTransfer       = els.modal.querySelector('#declTransfer,[data-role="decl-transfer"]');
    els.notasPaso1         = els.modal.querySelector('#notasPaso1,[data-role="notas-paso1"]');

    // Estados iniciales
    bindDenoms();
    ['declCredito','declDebito','declTransfer'].forEach(id=>{
      const el = els[id];
      if (el){
        el.value = (el.value===''? '0' : el.value);
        el.addEventListener('input', ()=>{ if (el.value==='') el.value='0'; recalcPaso1(); });
        el.addEventListener('blur',  ()=>{ if (el.value==='') el.value='0'; recalcPaso1(); });
      }
    });
    recalcPaso1();
    setStep(1);

    try {
      if (window.bootstrap?.Modal){
        window.bootstrap.Modal.getOrCreateInstance(els.modal, { backdrop:'static', keyboard:false }).show();
      } else {
        els.modal.classList.add('show'); els.modal.style.display='block'; document.body.classList.add('modal-open');
      }
    } catch(_){}

  } catch(e){
    if (e?.status === 409 && e?.payload?.tickets_abiertos != null){
      const n = e.payload.tickets_abiertos;
      toast(
        `No puedes iniciar precorte: hay ${n} ticket(s) abiertos en el POS. Ciérralos y vuelve a intentar.`,
        'warn', 0, 'Bloqueado',
        { sticky:true, actions:[{ label:'Reintentar', onClick:({close})=>{ close(); abrirWizard({ currentTarget: btn }); }}] }
      );
    } else {
      toast(`Error iniciando precorte: ${e.message}`, 'err', 15000, 'Error', {sticky:true});
    }
  } finally {
    btn.__busy = false;
  }
}

export async function guardarPrecorte(){
  if (!state.precorteId){ toast('No hay precorte activo','err', 9000, 'Error'); return; }

  let totalEf = 0;
  const denoms = [];
  state.denoms.forEach((qty,den)=>{ denoms.push({den,qty}); totalEf += den*qty; });

  const credito  = Number(els.declCredito?.value || 0);
  const debito   = Number(els.declDebito?.value  || 0);
  const transfer = Number(els.declTransfer?.value|| 0);
  const notas    = String(els.notasPaso1?.value || '');

  const resumen = `Efectivo: ${MXN.format(totalEf)} · TC: ${MXN.format(credito)} · TD: ${MXN.format(debito)} · Transf: ${MXN.format(transfer)}\n¿Guardar precorte?`;
  if (!window.confirm(resumen)) return;

  try{
    const payload = {
      denoms_json: JSON.stringify(denoms),
      declarado_credito:  credito,
      declarado_debito:   debito,
      declarado_transfer: transfer,
      notas
    };
    const j = await POST_FORM(api.precorte_update(state.precorteId), payload);
    if (!j?.ok){ toast('No se pudo guardar precorte','err', 9000, 'Error'); return; }
    state.pasoGuardado = true;
    if (els.btnContinuarConc) els.btnContinuarConc.disabled = false;
    toast('Precorte guardado','ok', 6000, 'Listo');

    setStep(2);
    await sincronizarPOS(true);

  }catch(e){
    toast(`Error guardando precorte: ${e.message}`,'err', 9000, 'Error');
  }
}

export async function sincronizarPOS(auto=false){
  if (!state.precorteId){ toast('No hay precorte activo','err', 9000, 'Error'); return; }
  if (els.bannerFaltaCorte) els.bannerFaltaCorte.classList.add('d-none');
  if (els.concGrid) els.concGrid.innerHTML = '<div class="text-muted small">Sincronizando con POS...</div>';

  try{
    const j = await GET(api.precorte_totales(state.precorteId));
    if (!j?.ok){
      if (els.bannerFaltaCorte) els.bannerFaltaCorte.classList.remove('d-none');
      if (!auto) toast('Falta cierre en POS o no hay datos','err', 9000, 'Sin datos');
      return;
    }
    const d = j.data || {};
    renderConciliacion(d, j);
    if (els.btnIrPostcorte) els.btnIrPostcorte.disabled = false;

  }catch(e){
    if (els.bannerFaltaCorte) els.bannerFaltaCorte.classList.remove('d-none');
    if (!auto) toast(`Sincronización fallida: ${e.message}`,'err', 9000, 'Error');
  }
}

function badgeVeredicto(diff){
  const ad = Math.abs(Number(diff||0));
  if (ad === 0) return '<span class="badge bg-success">CUADRA</span>';
  if (ad <= 10) return '<span class="badge bg-warning text-dark">±10</span>';
  return '<span class="badge bg-danger">DIF</span>';
}
function rowConc(name, declarado, sistema){
  const diff = Number(declarado||0) - Number(sistema||0);
  return `
    <tr>
      <td>${name}</td>
      <td class="text-end">${MXN.format(Number(declarado||0))}</td>
      <td class="text-end">${MXN.format(Number(sistema||0))}</td>
      <td class="text-end">${MXN.format(diff)}</td>
      <td class="text-center">${badgeVeredicto(diff)}</td>
    </tr>`;
}
export function renderConciliacion(d, raw){
  if (!els.concGrid) return;
  const efectivo_decl = Number(d?.efectivo?.declarado||0);
  const efectivo_sys  = Number(d?.efectivo?.sistema  ||0);
  const credito_decl  = Number(d?.tarjeta_credito?.declarado||0);
  const credito_sys   = Number(d?.tarjeta_credito?.sistema  ||0);
  const debito_decl   = Number(d?.tarjeta_debito?.declarado ||0);
  const debito_sys    = Number(d?.tarjeta_debito?.sistema   ||0);
  const transf_decl   = Number(d?.transferencias?.declarado ||0);
  const transf_sys    = Number(d?.transferencias?.sistema   ||0);

  const html = `
    <table class="table table-sm align-middle mb-2">
      <thead><tr>
        <th>Categoria</th><th class="text-end">Declarado</th><th class="text-end">Sistema</th><th class="text-end">Diferencia</th><th class="text-center">Estado</th>
      </tr></thead>
      <tbody>
        ${rowConc('Efectivo', efectivo_decl, efectivo_sys)}
        ${rowConc('Tarjeta Crédito', credito_decl, credito_sys)}
        ${rowConc('Tarjeta Débito',  debito_decl,  debito_sys)}
        ${rowConc('Transferencias',  transf_decl,  transf_sys)}
      </tbody>
    </table>
    <div class="small text-muted">Fondo de caja (opening_float): ${MXN.format(Number(raw?.opening_float||state.sesion.opening||0))}</div>
  `;
  els.concGrid.innerHTML = html;
}

export function bindModalButtons(){
  if (window.__CAJA_BOUND__) return;
  window.__CAJA_BOUND__ = true;
  if (els.btnGuardarPrecorte){
    els.btnGuardarPrecorte.addEventListener('click', guardarPrecorte);
    els.btnGuardarPrecorte.disabled = true;
  }
  if (els.btnContinuarConc){
    els.btnContinuarConc.addEventListener('click', ()=> setStep(2));
    els.btnContinuarConc.disabled = true;
  }
  if (els.btnSincronizarPOS){
    els.btnSincronizarPOS.addEventListener('click', ()=> sincronizarPOS(false));
  }
  if (els.btnIrPostcorte){
    els.btnIrPostcorte.addEventListener('click', ()=> setStep(3));
    els.btnIrPostcorte.disabled = true;
  }
  if (els.btnCerrarSesion){
    els.btnCerrarSesion.addEventListener('click', ()=>{
      try { bootstrap.Modal.getInstance(els.modal)?.hide(); } catch(_){}
      toast('Sesión cerrada (demo UI).', 'ok', 6000, 'Listo');
      import('./mainTable.js').then(m => m.cargarTabla().catch(()=>{}));
    });
  }
}
if (!window.abrirWizard) window.abrirWizard = abrirWizard;
