<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class PostCorteController {
public static function create(Request $request, Response $response, array $args = []): Response {
    $db = self::p();
    $precorte_id = (int) qp($request, 'precorte_id', 0);
    $sesion_id   = (int) qp($request, 'sesion_id', 0);

    if (!$sesion_id && $precorte_id){
        $s = $db->prepare("SELECT sesion_id FROM selemti.precorte WHERE id=:id");
        $s->execute([':id'=>$precorte_id]);
        $sesion_id = (int)($s->fetch()['sesion_id'] ?? 0);
    }
    if (!$sesion_id) return J($response, ['ok'=>false,'error'=>'missing_sesion'], 400);

    // ventana + terminal
    $w = $db->prepare("SELECT terminal_id, apertura_ts, COALESCE(cierre_ts, now()) AS cierre_ts
                       FROM selemti.sesion_cajon WHERE id=:sid");
    $w->execute([':sid'=>$sesion_id]);
    $rowW = $w->fetch();
    if(!$rowW) return J($response, ['ok'=>false,'error'=>'sesion_not_found'],404);

    // gate DPR
    if (!PreCorteController::hasPOSCut($db, (int)$rowW['terminal_id'], (string)$rowW['apertura_ts'], (string)$rowW['cierre_ts'])){
        return J($response, ['ok'=>false,'error'=>'pos_cut_missing'], 412);
    }

    // sistema
    $vw = $db->prepare("SELECT * FROM selemti.vw_conciliacion_sesion WHERE sesion_id=:sid");
    $vw->execute([':sid'=>$sesion_id]);
    $sys = $vw->fetch(\PDO::FETCH_ASSOC) ?: [];

    // inserta postcorte (ajusta columnas reales)
    $ins = $db->prepare("
      INSERT INTO selemti.postcorte (sesion_id, precorte_id, creado_en)
      VALUES (:sid, NULLIF(:pid,0), now())
      RETURNING id
    ");
    $ins->execute([':sid'=>$sesion_id, ':pid'=>$precorte_id]);
    $post_id = (int)$ins->fetchColumn();

    // (opcional) sesion estatus
    $db->prepare("UPDATE selemti.sesion_cajon SET estatus='CONCILIADO' WHERE id=:sid")
       ->execute([':sid'=>$sesion_id]);

    return J($response, ['ok'=>true, 'postcorte_id'=>$post_id, 'sesion_id'=>$sesion_id, 'sistema'=>$sys]);
}

}
