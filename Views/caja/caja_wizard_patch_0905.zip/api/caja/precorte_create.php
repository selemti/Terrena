\
<?php
declare(strict_types=1);
require_once __DIR__ . '/../../api/controllers/CajaController.php'; // path relative to this file

$ctrl = new CajaController();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $ctrl->createPrecorte();
} else {
  http_response_code(405);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['error'=>'Método no permitido']);
}
