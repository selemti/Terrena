\
<?php
declare(strict_types=1);
require_once __DIR__ . '/../../api/controllers/CajaController.php';

$ctrl = new CajaController();
$id = $_GET['id'] ?? null;
if (!$id) {
  http_response_code(400);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode(['error'=>'Falta parámetro id']);
  exit;
}
$ctrl->getSistemaPrecorte((int)$id);
