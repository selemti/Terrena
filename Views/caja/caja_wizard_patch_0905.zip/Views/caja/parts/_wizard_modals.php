\
<?php
/**
 * Wizard de Caja: Precorte → Corte (POS) → Conciliación → Postcorte
 * Requiere Bootstrap 5.3 y assets/js/caja.js
 * Inserta este partial en cortes.php o en layout.php (al final del <body>).
 */
$base = $GLOBALS['__BASE__'] ?? rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
?>
<!-- Modal: Precorte -->
<div class="modal fade" id="czModalPrecorte" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <form class="modal-content" id="czFormPrecorte" autocomplete="off">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa-solid fa-calculator me-2"></i> Precorte – Conteo rápido</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <input type="hidden" id="cz_precorte_id">
        <div class="row g-3">
          <div class="col-12">
            <div class="table-responsive">
              <table class="table table-sm align-middle mb-0" id="czTablaDenoms">
                <thead><tr><th>Denominación</th><th style="width:120px">Cantidad</th><th class="text-end" style="width:140px">Importe</th></tr></thead>
                <tbody><!-- filas por JS --></tbody>
                <tfoot>
                  <tr>
                    <th colspan="2" class="text-end">Total efectivo</th>
                    <th class="text-end" id="czPrecorteTotal">$0.00</th>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
          <div class="col-12">
            <div class="row g-2">
              <div class="col-6 col-md-3">
                <label class="form-label">Efectivo declarado</label>
                <input type="number" step="0.01" class="form-control" id="czDeclCash" value="0.00">
              </div>
              <div class="col-6 col-md-3">
                <label class="form-label">Tarjeta (total)</label>
                <input type="number" step="0.01" class="form-control" id="czDeclCard" value="0.00">
              </div>
              <div class="col-6 col-md-3">
                <label class="form-label">Transferencia</label>
                <input type="number" step="0.01" class="form-control" id="czDeclTransfer" value="0.00">
              </div>
              <div class="col-12 col-md-3">
                <label class="form-label">Observaciones</label>
                <input class="form-control" id="czNotes" placeholder="Opcional">
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="modal-footer justify-content-between">
        <div class="text-muted small" id="czPrecorteAutosave">Auto-guardado listo</div>
        <div class="d-flex gap-2">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-primary"><i class="fa-regular fa-floppy-disk me-1"></i> Guardar precorte</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Corte POS (snapshot) -->
<div class="modal fade" id="czModalCorte" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <div class="modal-content" id="czFormCorte">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa-regular fa-clipboard me-2"></i> Corte POS – Resumen del sistema</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <div id="czCorteResumen">
          <em>Sincroniza para ver totales…</em>
        </div>
      </div>
      <div class="modal-footer justify-content-between">
        <button class="btn btn-outline-secondary" id="czBtnSincronizarPOS"><i class="fa-solid fa-rotate me-1"></i> Sincronizar POS</button>
        <div class="d-flex gap-2">
          <button class="btn btn-light" data-bs-dismiss="modal">Cerrar</button>
          <button class="btn btn-primary" id="czBtnContinuarConciliacion" disabled>Continuar a Conciliación</button>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Modal: Conciliación -->
<div class="modal fade" id="czModalConciliacion" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-xl modal-dialog-centered">
    <form class="modal-content" id="czFormConciliacion">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa-solid fa-scale-balanced me-2"></i> Conciliación</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <div id="czConciliacionGrid"><!-- Declarado vs POS vs Diferencia por método --></div>
        <div class="mt-3">
          <label class="form-label">Notas / Causales</label>
          <textarea class="form-control" id="czConciliacionNotas" rows="2" placeholder="Obligatorio si la diferencia en efectivo ≠ 0"></textarea>
        </div>
      </div>
      <div class="modal-footer justify-content-between">
        <div class="text-muted small" id="czConciliacionStatus"></div>
        <div class="d-flex gap-2">
          <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
          <button type="submit" class="btn btn-success" id="czBtnFinalizarConciliacion"><i class="fa-solid fa-check me-1"></i> Finalizar</button>
        </div>
      </div>
    </form>
  </div>
</div>

<!-- Modal: Postcorte / Depósito -->
<div class="modal fade" id="czModalPostcorte" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
  <div class="modal-dialog modal-lg modal-dialog-centered">
    <form class="modal-content" id="czFormPostcorte" enctype="multipart/form-data">
      <div class="modal-header">
        <h5 class="modal-title"><i class="fa-solid fa-clipboard-check me-2"></i> Postcorte / Depósito</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      </div>
      <div class="modal-body">
        <div class="row g-3">
          <div class="col-md-4">
            <label class="form-label">Folio de depósito</label>
            <input class="form-control" id="czDepFolio">
          </div>
          <div class="col-md-4">
            <label class="form-label">Cuenta</label>
            <input class="form-control" id="czDepCuenta">
          </div>
          <div class="col-md-4">
            <label class="form-label">Comprobante</label>
            <input type="file" class="form-control" id="czDepAdjunto" accept="image/*,application/pdf">
          </div>
        </div>
      </div>
      <div class="modal-footer justify-content-between">
        <button type="button" class="btn btn-light" data-bs-dismiss="modal">Cancelar</button>
        <div class="d-flex gap-2">
          <button class="btn btn-primary" id="czBtnGuardarPostcorte">Guardar Postcorte</button>
          <button class="btn btn-dark" id="czBtnCerrarSesion" disabled>Cerrar Sesión</button>
        </div>
      </div>
    </form>
  </div>
</div>
