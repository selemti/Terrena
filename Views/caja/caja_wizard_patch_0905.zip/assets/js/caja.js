\
/**
 * assets/js/caja.js — Orquestación del flujo de Cajas
 * Integración mínima: usa endpoints en /api/caja/...
 * Requiere Bootstrap 5
 */
(function(){
  const MXN = new Intl.NumberFormat('es-MX',{style:'currency',currency:'MXN'});
  const denoms = [1000,500,200,100,50,20,10,5,2,1,0.5];
  let autosaveTimer = null;
  let precorteId = null;
  let sysTotals = {cash:0, card:0, transfer:0};
  let decl = {cash:0, card:0, transfer:0};

  // Helpers DOM
  function el(id){ return document.getElementById(id); }
  function toast(msg, cls){ try {
    const t = document.createElement('div');
    t.className = 'cz-toast ' + (cls||''); t.textContent = msg;
    document.body.appendChild(t);
    setTimeout(()=>{ t.classList.add('show'); }, 10);
    setTimeout(()=>{ t.classList.remove('show'); t.remove(); }, 3000);
  } catch(_){} }

  // Render filas de denominaciones
  function renderDenoms(){
    const tbody = document.querySelector('#czTablaDenoms tbody');
    if (!tbody) return;
    tbody.innerHTML = '';
    denoms.forEach(v => {
      const tr = document.createElement('tr');
      tr.innerHTML = `<td>$${v}</td>
        <td><input type="number" min="0" class="form-control form-control-sm cz-qty" data-val="${v}" value="0"></td>
        <td class="text-end cz-amt" data-val="${v}">$0.00</td>`;
      tbody.appendChild(tr);
    });
    tbody.addEventListener('input', onQtyChange);
  }

  function recalcTotal(){
    let sum = 0;
    document.querySelectorAll('.cz-qty').forEach(inp => {
      const v = parseFloat(inp.dataset.val);
      const q = parseInt(inp.value||'0',10);
      if (!isNaN(v) && !isNaN(q)) sum += v*q;
      const amt = inp.closest('tr').querySelector('.cz-amt');
      if (amt) amt.textContent = MXN.format((v*q)||0);
    });
    el('czPrecorteTotal').textContent = MXN.format(sum);
    return sum;
  }

  function onQtyChange(){
    recalcTotal();
    // autosave throttle
    clearTimeout(autosaveTimer);
    autosaveTimer = setTimeout(()=>{
      autosave();
    }, 500);
  }

  async function autosave(){
    if (!precorteId) return;
    const conteo = [];
    document.querySelectorAll('.cz-qty').forEach(inp => {
      const v = parseFloat(inp.dataset.val);
      const q = parseInt(inp.value||'0',10);
      conteo.push({den:v, qty:q});
    });
    try {
      await fetch(`/api/caja/precorte_update.php?id=${encodeURIComponent(precorteId)}`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({conteo_efectivo: conteo})
      });
      el('czPrecorteAutosave').textContent = 'Borrador guardado';
    } catch (e) {
      el('czPrecorteAutosave').textContent = 'Error de autosave';
    }
  }

  // Guardar precorte (definitivo)
  async function onSubmitPrecorte(ev){
    ev.preventDefault();
    decl.cash = parseFloat(el('czDeclCash').value||'0');
    decl.card = parseFloat(el('czDeclCard').value||'0');
    decl.transfer = parseFloat(el('czDeclTransfer').value||'0');
    const notas = el('czNotes').value||'';

    try {
      const resp = await fetch(`/api/caja/precorte_update.php?id=${encodeURIComponent(precorteId)}`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({
          declarados: {cash: decl.cash, card: decl.card, transfer: decl.transfer},
          notes: notas
        })
      });
      if (!resp.ok) throw new Error('No se pudo guardar precorte');
      toast('Precorte guardado', 'ok');
      // Abrir Corte
      const modalPrec = bootstrap.Modal.getOrCreateInstance('#czModalPrecorte');
      modalPrec.hide();
      bootstrap.Modal.getOrCreateInstance('#czModalCorte').show();
    } catch (e) {
      toast('Error al guardar precorte', 'err');
    }
  }

  // Sincronizar POS
  async function syncPOS(){
    try {
      const r = await fetch(`/api/caja/precorte_totales.php?id=${encodeURIComponent(precorteId)}`);
      const j = await r.json();
      sysTotals.cash = j.sys_cash||0;
      sysTotals.card = j.sys_card||0;
      sysTotals.transfer = j.sys_transfer||0;
      renderCorteResumen();
      el('czBtnContinuarConciliacion').disabled = false;
    } catch (e) {
      toast('No fue posible sincronizar POS', 'err');
    }
  }

  function renderCorteResumen(){
    const box = el('czCorteResumen');
    if (!box) return;
    box.innerHTML = `
      <div class="row g-3">
        <div class="col-md-4"><div class="kpi"><div class="kpi-label">POS – Efectivo</div><div class="kpi-value">${MXN.format(sysTotals.cash)}</div></div></div>
        <div class="col-md-4"><div class="kpi"><div class="kpi-label">POS – Tarjeta</div><div class="kpi-value">${MXN.format(sysTotals.card)}</div></div></div>
        <div class="col-md-4"><div class="kpi"><div class="kpi-label">POS – Transferencia</div><div class="kpi-value">${MXN.format(sysTotals.transfer)}</div></div></div>
      </div>
    `;
  }

  function renderConciliacion(){
    const grid = el('czConciliacionGrid');
    if (!grid) return;
    const rows = [
      {label:'Efectivo', decl:decl.cash, pos:sysTotals.cash},
      {label:'Tarjeta', decl:decl.card, pos:sysTotals.card},
      {label:'Transferencia', decl:decl.transfer, pos:sysTotals.transfer},
    ];
    const html = [`<div class="table-responsive"><table class="table table-sm align-middle mb-0">
      <thead><tr><th>Método</th><th class="text-end">Declarado</th><th class="text-end">POS</th><th class="text-end">Diferencia</th></tr></thead><tbody>`];
    let diffCash = 0;
    rows.forEach(r => {
      const diff = (r.decl||0) - (r.pos||0);
      if (r.label==='Efectivo') diffCash = diff;
      html.push(`<tr><td>${r.label}</td><td class="text-end">${MXN.format(r.decl||0)}</td><td class="text-end">${MXN.format(r.pos||0)}</td><td class="text-end ${diff===0?'':'text-${diff>0?'success':'danger'}'}">${MXN.format(diff)}</td></tr>`);
    });
    html.push(`</tbody></table></div>`);
    grid.innerHTML = html.join('');
    el('czConciliacionStatus').textContent = diffCash===0 ? 'Efectivo conciliado' : 'Requiere nota por diferencia en efectivo';
  }

  // Eventos globales (botones que abren el wizard)
  function wireGlobalButtons(){
    document.querySelectorAll('[data-caja-action="wizard"]').forEach(btn => {
      btn.addEventListener('click', async () => {
        // Requiere atributos data-* con store_id, terminal_id, user_id, bdate
        const store = btn.getAttribute('data-store');
        const term  = btn.getAttribute('data-terminal');
        const user  = btn.getAttribute('data-user') || '1';
        const bdate = btn.getAttribute('data-bdate') || new Date().toISOString().slice(0,10);
        // Crear precorte si no existe
        if (!precorteId){
          const r = await fetch('/api/caja/precorte_create.php', {
            method:'POST',
            headers:{'Content-Type':'application/json'},
            body: JSON.stringify({bdate, store_id:store, terminal_id:term, user_id:user})
          });
          const j = await r.json();
          precorteId = j.precorte_id;
          el('cz_precorte_id').value = precorteId;
        }
        // Reset UI
        renderDenoms(); recalcTotal();
        el('czDeclCash').value = el('czDeclCard').value = el('czDeclTransfer').value = '0.00';
        // Abrir modal
        bootstrap.Modal.getOrCreateInstance('#czModalPrecorte').show();
      });
    });

    // Corte
    el('czBtnSincronizarPOS')?.addEventListener('click', syncPOS);
    el('czBtnContinuarConciliacion')?.addEventListener('click', () => {
      bootstrap.Modal.getOrCreateInstance('#czModalCorte').hide();
      renderConciliacion();
      bootstrap.Modal.getOrCreateInstance('#czModalConciliacion').show();
    });

    // Finalizar conciliación (solo UX; persistencia específica dependerá del backend)
    el('czFormConciliacion')?.addEventListener('submit', (ev)=>{
      ev.preventDefault();
      const diffText = el('czConciliacionStatus').textContent||'';
      if (diffText.includes('Requiere nota') && !(el('czConciliacionNotas').value||'').trim()){
        alert('Describe la causa de la diferencia en efectivo.');
        return;
      }
      toast('Conciliación finalizada', 'ok');
      bootstrap.Modal.getOrCreateInstance('#czModalConciliacion').hide();
      bootstrap.Modal.getOrCreateInstance('#czModalPostcorte').show();
    });

    // Postcorte (solo UX)
    el('czBtnGuardarPostcorte')?.addEventListener('click', (ev)=>{
      ev.preventDefault();
      toast('Postcorte guardado (pendiente integración de backend)', 'ok');
      el('czBtnCerrarSesion').disabled = false;
    });
  }

  // Precorte submit
  el('czFormPrecorte')?.addEventListener('submit', onSubmitPrecorte);

  // Inicia
  document.addEventListener('DOMContentLoaded', () => {
    wireGlobalButtons();
  });
})();
