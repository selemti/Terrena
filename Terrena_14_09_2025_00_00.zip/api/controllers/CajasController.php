<?php
use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

class CajasController {

  /** Resuelve PDO sin tocar tu core */
  private static function p(): PDO {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    // 1) Intenta /api/config.php y luego /config.php (ambos ya existen en tu proyecto)
    $candidates = [
      __DIR__ . '/../config.php',   // /api/config.php
      __DIR__ . '/../../config.php' // /config.php
    ];
    foreach ($candidates as $c) {
      if (is_file($c)) {
        $r = require $c;
        if ($r instanceof PDO) { $pdo = $r; return $pdo; }
      }
    }

    // 2) Fallback a tu helper actual (que llama a Terrena\Core\Database::pdo())
    if (function_exists('pdo')) {
      $pdo = pdo();
      if ($pdo instanceof PDO) return $pdo;
    }

    throw new RuntimeException('No fue posible inicializar PDO en CajasController.');
  }

  /**
   * GET/POST /caja/cajas.php?date=YYYY-MM-DD
   * Respuesta compatible con tu JS legacy.
   */
public static function cajas(Request $request, Response $response, array $args = [])
{
    // Fallbacks por si no están cargados en este contexto
    if (!function_exists('qp')) {
        function qp(Request $r, $k, $def=null){ $q=$r->getQueryParams(); $p=(array)$r->getParsedBody(); return $q[$k]??$p[$k]??$def; }
    }
    if (!function_exists('J')) {
        function J(Response $res, $arr, $code=200){ $res=$res->withHeader('Content-Type','application/json')->withStatus($code); $res->getBody()->write(json_encode($arr)); return $res; }
    }

    try {
        // DB
        $db = null;
        if (method_exists(__CLASS__, 'p')) { $db = self::p(); }
        if (!($db instanceof \PDO)) {
            require_once __DIR__ . '/../core/database.php';
            if (isset($pdo) && $pdo instanceof \PDO) $db = $pdo;
        }
        if (!($db instanceof \PDO)) throw new \RuntimeException('DB no inicializada');

        // Fecha
        $date = trim((string) (qp($request, 'date', date('Y-m-d'))));
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');
        $d0 = $date.' 00:00:00';
        $d1 = date('Y-m-d', strtotime($date.' +1 day')).' 00:00:00';

        // Terminales + última sesión que cruza el día
        $sql = "
        SELECT
          t.id,
          t.name,
          COALESCE(t.location,'')                       AS location,
          t.assigned_user,
          (u.first_name||' '||u.last_name)              AS assigned_name,
          COALESCE(t.opening_balance,0)::numeric(12,2)  AS opening_balance,
          COALESCE(t.current_balance,0)::numeric(12,2)  AS current_balance,
          s.id                                          AS sesion_id,
          s.opening_float::numeric(12,2)                AS opening_float,
          (s.cierre_ts IS NULL)                         AS sesion_activa,
          s.estatus                                     AS sesion_estatus
        FROM public.terminal t
        LEFT JOIN public.users u
               ON u.auto_id = t.assigned_user
        LEFT JOIN (
          SELECT DISTINCT ON (terminal_id)
                 id, terminal_id, apertura_ts, cierre_ts, opening_float, estatus
          FROM selemti.sesion_cajon
          WHERE apertura_ts <  :d1
            AND COALESCE(cierre_ts, :d1) >= :d0
          ORDER BY terminal_id, apertura_ts DESC
        ) s ON s.terminal_id = t.id
        ORDER BY t.id";
        $st = $db->prepare($sql);
        $st->execute([':d0'=>$d0, ':d1'=>$d1]);

        $terminals = [];
        foreach ($st as $r) {
            $sid     = $r['sesion_id'] ?? null;
            $estatus = (string)($r['sesion_estatus'] ?? '');

            // ventas del día por terminal (opcional; si no aplica, dejar 0)
            $ventas = 0.0;

            $terminals[] = [
                'id'              => (int)$r['id'],
                'name'            => (string)$r['name'],
                'location'        => (string)$r['location'],
                'assigned_user'   => $r['assigned_user'] ? (int)$r['assigned_user'] : null,
                'assigned_name'   => $r['assigned_name'] ?: null,
                'opening_balance' => (float)$r['opening_balance'],
                'opening_float'   => isset($r['opening_float']) ? (float)$r['opening_float'] : null,
                'window'          => ['day'=>$date],
                'sales'           => ['terminal_total'=>$ventas],
                'sesion_estatus'  => $estatus, // opcional: texto del estatus
                'status'          => [
                    'asignada'         => (bool)$r['assigned_user'],
                    'activa'           => (bool)$r['sesion_activa'],
                    'sesion_id'        => $sid ? (int)$sid : null,
                    'listo_para_corte' => ($estatus === 'LISTO_PARA_CORTE'),
                ],
                'sesion'          => $sid ? ['id'=>(int)$sid] : null,
            ];
        }

        return J($response, ['ok'=>true, 'date'=>$date, 'terminals'=>$terminals]);
    } catch (\Throwable $e) {
        return J($response, ['ok'=>false, 'error'=>'server_error', 'detail'=>$e->getMessage()], 500);
    }
}



  /** /caja/cajas_debug.php */
  public static function cajasDebug(Request $req, Response $res): Response {
    return self::cajas($req, $res);
  }
}
